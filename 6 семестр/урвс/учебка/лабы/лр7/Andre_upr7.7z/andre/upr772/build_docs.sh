#!/bin/sh

doxygen upr770.cfg
