./upr770 > res
{
cmp cmps/cmp1 res && 
echo "Test 1 successfully passed"
} || echo "Test 1 failed!"

sleep 5
