/**
 * @file main.cpp
 * @detailed The programme that able to demonstrate interaction of forked processes
 * @author Kurochkin A.V.
 * @version 0.1
 */
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/msg.h>
#include <string.h>
#include <errno.h>
#define BUF_SIZE 128
#define BIG_BUF_SIZE 2048
//<! Сообщение
struct message
{
    long mtype;//!< Тип сообщения
    char mtext[BUF_SIZE];//!< Текст сообщения
};
//<! Семафоры
union sem
{
    int val;
    struct semid_ds *buf;
    unsigned short *array;
};
/* @brief Обработка ошибки
 * @param buf текст ошибки
 */
void error(const char *buf)
{
    printf("ERROR: %s\n", buf);
    exit(1);
}
//<! Основная подпрограмма
int main()
{
    int msgqid = msgget(IPC_PRIVATE, IPC_CREAT | 0600);//<! Создание очереди сообщений
    if (msgqid == -1) error("Не могу создать очередь сообщений.");
    int semid = semget(IPC_PRIVATE, 1, IPC_CREAT| 0600);
    if (semid == -1) error("Не могу создать семафоры.");
    sem semun;//!< Семафоры
    message msg;//!< Сообщение
    for(int idchld = 0; idchld < 4; idchld++)
    {
        switch (fork())//!< Порождаем процессы-потомки, получая идентификатор
        {
            case -1: error("Не могу породить процесс");//!< Ошибка
            case  0: //!< Если это дочерний процесс
            {
                semun.val = 1;
                for(int i=idchld; i<12; i+=4)
                {
                    msg.mtype = i+1;
                    switch (i)//!< Выбираем строку в зависимости от номера процесса-потомка
                    {
                        case 0: strcpy(msg.mtext, "I shot an arrow into the air,"); break;
                        case 1: strcpy(msg.mtext, "It fell to earth, I knew not where;"); break;
                        case 2: strcpy(msg.mtext, "For, so swiftly it flew, the sight"); break;
                        case 3: strcpy(msg.mtext, "Could not follow it in its flight.\n"); break;
                        case 4: strcpy(msg.mtext, "I breathed a song into the air,"); break;
                        case 5: strcpy(msg.mtext, "It fell to earth, I knew not where;"); break;
                        case 6: strcpy(msg.mtext, "For who has sight so keen and strong,"); break;
                        case 7: strcpy(msg.mtext, "That it can follow the flight of song?\n"); break;
                        case 8: strcpy(msg.mtext, "Long, long afterward, in an oak"); break;
                        case 9: strcpy(msg.mtext, "I found the arrow, still unbroke;"); break;
                        case 10: strcpy(msg.mtext, "And the song, from beginning to end,"); break;
                        case 11: strcpy(msg.mtext, "I found again in the heart of a friend."); break;
                    }
                    //!< Посылаем сообщение или обрабатываем ошибку
                    if(msgsnd(msgqid, &msg, BUF_SIZE, IPC_NOWAIT) == -1)
                        error("Не могу отправить сообщение.");
                    //!< Установка семафора или обработка ошибки
                    if(semctl(semid, i, SETVAL, semun) == -1)
                        error("Не могу поставить семафор.");
                }
                exit(0);
            }
        }
    }
    char buf[BIG_BUF_SIZE] = "\0";//!< Полное стихотворение
    for (int i=0; i<12;)//!< "вытаскиваем" строки в цикле
    {
        int val = semctl(semid, i, GETVAL);//!< Значение текущего семафора
        if(val == -1) error("Не могу получить значение семафора.");
	//sleep(rand()%1000);
        if(val == 1)
        {//!< Пытаемся принять сообщение
            if(msgrcv(msgqid, &msg, BUF_SIZE, (i+1), IPC_NOWAIT) == -1)
                error("Не могу принять сообщение.");
            strcat(buf, msg.mtext);//!< Пишем сообщение в стихотворения
            strcat(buf, "\n");
            i++;
        }
    }
    printf("%s", buf);//!< Выводим сообщение
    return 0;
}
