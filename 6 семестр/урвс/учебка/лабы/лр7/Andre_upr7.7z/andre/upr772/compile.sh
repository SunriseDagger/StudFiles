#!/bin/sh
g++ -o upr770 sources/main.cpp
