//! Лабораторная работа №7 по предмету УРвВС
/*
 * Программа пользуясь очередью сообщений и семафорами составляет стихотворение из кусков, которые ей отправляют дочерние процессы.
 *
 * \file main.cpp
 * \author ПМИ-71, бригада №7, Артамонов А.А. и Машкин М.С.
 */

#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/msg.h>
#include <string.h>
#include <errno.h>

#define BUF_SIZE 64
#define BIG_BUF_SIZE 768

//! Структура сообщений
struct message
{
    long mtype; //!< Тип сообщения
    char mtext[BUF_SIZE]; //!< Текст сообщения
};

//! Информация о семафорах
union sem
{
    int val; //!< Значение семафора
    struct semid_ds *buf; //!< Разная информация о семафоре
    unsigned short *array; //!< Значения семафоров
};

//! Функция выводит текст ошибки и прерывает выполнение программы.
/*!
 * \param buf текст ошибки.
 */
void error(const char *buf)
{
    printf("ERROR: %s\n", buf);
    exit(1);
}

//!Создание дочерних процессов
/*!
 * Функция создает дочерный процесс, который отправляет каждые четыре строки стихотворения начиная с номера n в очередь сообщений
 * с идентификатором msgqid и ставит соответствующий семафор в semid.
 * \param n номер первой строки.
 * \param semid идентификатор семафоров
 * \param msgqid идентификатор очереди сообщений
 */
void _fork(int n, int semid, int msgqid)
{
    sem semun; //!< Структура в которой хранится и передается информация о семафорах
    message msg; //!< Сообщение в очереди сообщений
    switch (fork())
    {
        case -1: error("Не могу породить процесс");
        case  0:
        {
            // Дочерний процесс
            semun.val = 1;
            for(int i=n; i<12; i+=4)
            {
                msg.mtype = i+1;
                switch (i)
                {
                    case 0: strcpy(msg.mtext, "Я помню чудное мгновенье:"); break;
                    case 4: strcpy(msg.mtext, "В томленьях грусти безнадежной"); break;
                    case 8: strcpy(msg.mtext, "Шли годы. Бурь порыв мятежный"); break;
                    case 1: strcpy(msg.mtext, "Передо мной явилась ты,"); break;
                    case 5: strcpy(msg.mtext, "В тревогах шумной суеты,"); break;
                    case 9: strcpy(msg.mtext, "Рассеял прежние мечты,"); break;
                    case 2: strcpy(msg.mtext, "Как мимолетное виденье,"); break;
                    case 6: strcpy(msg.mtext, "Звучал мне долго голос нежный"); break;
                    case 10: strcpy(msg.mtext, "И я забыл твой голос нежный,"); break;
                    case 3: strcpy(msg.mtext, "Как гений чистой красоты."); break;
                    case 7: strcpy(msg.mtext, "И снились милые черты."); break;
                    case 11: strcpy(msg.mtext, "Твои небесные черты."); break;
                }
                // Отправляем сообщение
                if (msgsnd(msgqid, &msg, BUF_SIZE, IPC_NOWAIT)==-1)
                    error("Не могу отправить сообщение.");
                // Выставляем семафор
                if (semctl(semid, i, SETVAL, semun)==-1)
                    error("Не могу поставить семафор.");
            }
            exit(0);
        }
    }
}

//! Основная функция
/*!
 * Создает четрые процесса, каждый из которых отправляет три строки стихотворения исходному процессу через очередь сообщений, а затем ставит семафор, говорящий что можно читать строку.
 * Исходный процесс собирает все строки в правильном порядке и выводит их.
 */
int main(int argc, char** argv)
{
    int msgqid; //!< Идентификатор очереди сообщений
    msgqid = msgget(IPC_PRIVATE, IPC_CREAT | 0600);
    if (msgqid == -1) error("Не могу создать очередь сообщений.");
    int semid; //!< Идентификатор семафоров
    semid = semget(IPC_PRIVATE, 12, IPC_CREAT| 0600);
    if (semid == -1) error("Не могу создать семафоры.");
    sem semun; //!< Структура в которой хранится и передается информация о семафорах
    message msg; //!< Сообщение в очереди сообщений

    _fork(0, semid, msgqid);
    _fork(1, semid, msgqid);
    _fork(2, semid, msgqid);
    _fork(3, semid, msgqid);

    char buf[BIG_BUF_SIZE] = "\0"; //!< Все стихотворение целиком
    for (int i=0; i<12; )
    {
        int val; //!< Значение текущего семафора
        val = semctl(semid, i, GETVAL);
        if (val == -1) error("Не могу получить значение семафора.");
        if (val == 1)
        {
            if (msgrcv(msgqid, &msg, BUF_SIZE, (i+1), IPC_NOWAIT)==-1)
                error("Не могу принять сообщение.");
            strcat(buf, msg.mtext);
            strcat(buf, "\n");
            if (i%4 == 3) strcat(buf, "\n");
            i++;
        }
    }
    printf("%s", buf);
    return (EXIT_SUCCESS);
}