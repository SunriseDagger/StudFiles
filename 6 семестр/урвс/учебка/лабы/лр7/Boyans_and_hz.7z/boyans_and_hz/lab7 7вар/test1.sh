#!/bin/bash
./pwnz 
