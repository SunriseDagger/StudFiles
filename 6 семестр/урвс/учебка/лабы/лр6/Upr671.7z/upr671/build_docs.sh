#!/bin/sh

doxygen upr670.cfg
