g++ -o tests/test1/upr670 sources/main.cpp
g++ -o tests/test2/upr670 sources/main.cpp
g++ -o tests/test3/upr670 sources/main.cpp
cd tests/test1
./upr670 1>../../cmps/r11 2>../../cmps/r21
cd ../test2
./upr670 1>../../cmps/r12 2>../../cmps/r22
cd ../test3
./upr670 1>../../cmps/r13 2>../../cmps/r23
cd ../..
{
cmp cmps/c11 cmps/r11 && 
cmp cmps/c21 cmps/r21 && 
echo "Test 1 successfully passed"
} || echo "Test 1 failed!"
{
cmp cmps/c12 cmps/r12 && 
cmp cmps/c22 cmps/r22 && 
echo "Test 2 successfully passed"
} || echo "Test 2 failed!"
{
cmp cmps/c13 cmps/r13 && 
cmp cmps/c23 cmps/r23 && 
echo "Test 3 successfully passed"
} || echo "Test 3 failed!"
sleep 5
