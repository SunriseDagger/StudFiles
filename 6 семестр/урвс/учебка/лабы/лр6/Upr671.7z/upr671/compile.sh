#!/bin/sh
g++ -o upr670 sources/main.cpp
