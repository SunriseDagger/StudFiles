/**
 * @file main.cpp
 * @author Kurochkin A.V.
 * @version 0.1
 */
#include <sys/wait.h>
#include <string.h>
#include <signal.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>

#define out stderr

/** 
 * The main function
 */
int main()
{
    int pipeFd1[2], pipeFd2[2], w;
    pipe(pipeFd1);
    pipe(pipeFd2);
    fprintf(out, "Forking the first child.\n");
    if(!fork())
    {
        fprintf(out, "Closing excess of file descriptors.\n");
        close(pipeFd2[0]);
        close(pipeFd2[1]);
        close(pipeFd1[0]); //<! 0, pipeFd1[1] opened
        close(1);
        fprintf(out, "Doing redirection of input and output.\n");
        dup(pipeFd1[1]);//<! Use stdin
        fprintf(out, "cat a.txt b.txt c.txt.\n");
        execl("/bin/cat", "cat", "a.txt", "b.txt", "c.txt", 0);
        exit(0);
    }
    sleep(1);
    fprintf(out, "Forking the second child.\n");
    if(!fork())
    {
        close(pipeFd2[0]);
        close(pipeFd1[1]);//<! pipeFd2[1], pipeFd1[2] opened
        fprintf(out, "Closing excess of file descriptors.\n");
        fprintf(out, "Doing redirection of input and output.\ntr -d ""[a-i]"".\n");
        close(0);
        dup(pipeFd1[0]);//<! Use 0
        close(1);
        dup(pipeFd2[1]);//<! Use 1
        execl("/usr/bin/tr", "tr", "-d", """[a-i]""", 0);
        exit(0);
    }
    sleep(1);
    fprintf(out, "Forking the third child.\n");
    if(!fork())
    {
        fprintf(out, "Closing excess of file descriptors.\n");
        close(pipeFd1[0]);
        close(pipeFd1[1]);
        close(pipeFd2[1]);//<! pipeFd2[0]
        close(0);
        dup(pipeFd2[0]);
        fprintf(out, "Doing redirection of input and output.\n");
        fprintf(out,"cat a.txt b.txt c.txt|tr -d ""[a-i]""|wc -w\n");
        execl("/usr/bin/wc", "wc", "-w", 0);
        exit(0);
    }
    wait(&w);
    return 0;
}
