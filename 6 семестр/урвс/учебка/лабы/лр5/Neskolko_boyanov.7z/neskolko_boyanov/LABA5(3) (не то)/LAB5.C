#include <sys/types.h>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>

int pid1=0, pid2=0;
int fd[2];

struct data {
 long int pd;   //process identificator (4b)
 char mp[40];   //process message (40b)
} p_data;

static void SIGP(int sig)
{ 
  signal(SIGUSR1, SIGP);
  printf("P2: received signal from P1.\n");
  printf("P2: send message to P0.\n");
  p_data.pd=pid2; strcpy(p_data.mp,"P2: reading file has finished.");
  write(fd[1], &p_data, sizeof(p_data));  
  exit(0);
}  
  
int main()      //main procedure
{
  int t=1, l, f;
  char c;
  
  signal(SIGUSR1, SIGP);
  
  printf("\n\nP0: started.\n\n");
  printf("P0: creat program pipe.\n");
  pipe(fd);     //process P0 creats the program pipe K1
  printf("P0: creat process P1.\n");
  pid1=fork();  //process P0 creats process P1
  if (pid1==-1) printf("Can't creat the process.\n");
  if (pid1==0)
  {
    pid2=fork();  //process P1 creats process P2  
    if (pid2==-1) printf("Can't creat the process.\n");
    if (pid2==0)
    { //process P2 open file for reading   
      if ((f=open("large.txt", O_RDONLY))!=-1)
      { 
        printf("P2: start read file.\n");                  
        while (t==1)
	 t=read(f, &c, sizeof(char));
	printf("P2: I've read the file!!!\n"); 
	pause();
      }
      else 
      {
          printf("P2: file does not exist.\n");
	  pause();
      }      
    }
    else
    { //working process P1
      printf("P1: send message to P0.\n");
      p_data.pd=getpid(); strcpy(p_data.mp,"P1: creat process P2.");
      write(fd[1], &p_data, sizeof(p_data)); //send data in pipe
      printf("P1: sleep for a time\n");
      sleep(3);                              //sleep for a 1 second 
      printf("P1: wake up and send signal to P2.\n");                  
      kill(pid2, SIGUSR1);                   //send signal to P2
      wait(&l);
      printf("P1: send message to P0.\n");
      p_data.pd=getpid(); strcpy(p_data.mp,"P1: kill process P2.");
      write(fd[1], &p_data, sizeof(p_data)); //send data in pipe 
      exit(0);
    }
  }
  else
  { //working process P0
    read(fd[0], &p_data, sizeof(p_data));
    printf("\nP0 received message>  "); printf("%s\n\n", p_data.mp);
    read(fd[0], &p_data, sizeof(p_data));
    printf("\nP0 received message>  "); printf("%s\n\n", p_data.mp);
    read(fd[0], &p_data, sizeof(p_data));
    printf("\nP0 received message>  "); printf("%s\n\n", p_data.mp);
    wait(&l);
    printf("P0: all processes have been destructed.\n");
    printf("\nDone...\n\n");
  }    
}    