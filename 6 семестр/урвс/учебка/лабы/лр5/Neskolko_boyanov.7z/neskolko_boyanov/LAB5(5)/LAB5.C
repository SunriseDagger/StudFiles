#include<stdio.h>
#include<stdlib.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<fcntl.h>
#include<signal.h>
#include<unistd.h>
void empty(int a){};
main()
{
struct stat st;
unsigned long int n,r,ni[15];
unsigned long int i,j,k,l,m,p,q,res;
unsigned long int fac[15];
char ch[3];
int status,c,ii;
int fd,fd1,help,pid[20];
signal(SIGUSR1,&empty);
mknod("fn",010666,0);
mknod("fnr",010666,0);
mknod("hlp",010666,0);
fd=open("fn",O_RDWR);
fd1=open("fnr",O_RDWR);
help=open("hlp",O_RDWR);
puts("Input n");scanf("%d",&n);
write(fd,&n,sizeof(n));
puts("Input r");scanf("%d",&r);
for(i=1;i<r+1;i++)
{printf("Input n(%d)\n",i);
scanf("%d",&j);ni[i]=j;
write(fd1,&j,sizeof(j));
};
q=0;
for(i=1;i<r+1;i++)
q=q+ni[i];
if((q!=n)||(r>n)||(n<=0)||(r<=0))
{puts("incorrect numbers");
exit(0);
};
if (!(pid[1]=fork()))
{signal(SIGUSR1,&empty);
pause();
execl("proc1","proc1",0);
signal(SIGUSR1,&empty);
//kill(getppid(),SIGUSR1);
pause();
exit(0);
};


for(i=1;i<r+1;i++)
if(!(pid[i+1]=fork()))
{signal(SIGUSR1,&empty);
pause();
sprintf(ch,"%d",i);
execl("proc2","proc2",ch,0);
signal(SIGUSR1,&empty);
//kill(getppid(),SIGUSR1);
pause();
exit(0);
};
signal(SIGUSR1,&empty);
for(i=1;i<r+2;i++)kill(pid[i],SIGUSR1);

c=0;
for(;;)
{if(read(help,&ii,sizeof(ii))==sizeof(ii))c++;
if(c==r+1)break;
};
signal(SIGUSR1,&empty);
for(i=1;i<r+2;i++)kill(pid[i],SIGUSR1);
read(fd,&m,sizeof(m));
fac[1]=m;
printf("n!=%d\n",m);
for(i=1;i<r+1;i++)
{read(fd1,&m,sizeof(m));
fac[i+1]=m;
printf("n(%d)!=%d\n",i,m);
};

res=fac[1];
for(i=2;i<r+2;i++)
res=res/fac[i];
printf("Result:%d\n",res);
close(fd);
close(fd1);
close(help);
exit(0);

}


