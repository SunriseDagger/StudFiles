/**
 * @file main.cpp
 * @detailed The programme that able to demonstrate interaction of forked processes
 * @author Kurochkin A.V.
 * @author Popkov I.V.
 * @version 0.1
 */
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <wait.h>
#include <string.h>

int fd[2];
int pid1;
int pid2;
/** 
 * @brief The structure of pipe-message
 */
struct MsgStruct
{
    int num;//<! Number of process
    char mes[40];//<! Body of message
}   ms_to_write;//<! It`s instance
/** 
 * @brief The procedure of signal reaction
 * @param Signal
 */
void SigReact(int sig)
{ 
    signal(SIGUSR1, SigReact);
    printf("P2: received a signal from P1\n");
    printf("P2: sending a message to P0\n");
    ms_to_write.num = pid2;
    strcpy(ms_to_write.mes,"P2: finished reading a file");//<! Write a message in the pipe
    write(fd[1], &ms_to_write, sizeof(ms_to_write));  
    exit(0);
}  
/** 
 * @brief The main function
 */
int main()
{
    int f, l, flag = 1;
    char s;
    signal(SIGUSR1, SigReact);
    printf("\nP0: the start of programme\n");
    printf("P0: pipe creation\n");   
    pipe(fd);//<! Creation of a pipe
    printf("P0: creating P1\n");
    pid1 = fork();//<! Creation of a process
    if (pid1 == 0)//<! P1 section
    {
        pid2 = fork();//<! Creation of a process
        if(pid2 == 0)//<! P2 section
        {  
            if((f = open("file.txt", O_RDONLY)) != -1)//<! Open a file
                { 
                    printf("P2: started to read a file\n");                  
                    while (flag == 1)//<! We read, while we able to read
                        flag = read(f, &s, sizeof(char));
                    pause();//<! Waiting for a signal
                }
	    exit(0);
        }
    else//<! P1 section
        {
            //printf("P1: sending a message to P0\n");
            ms_to_write.num = getpid();//<! Getting self idn
            strcpy(ms_to_write.mes,"P1: creating P2");//<! Send a message in the pipe
            write(fd[1], &ms_to_write, sizeof(ms_to_write));
            printf("P1: waiting\n");
            sleep(4);//<! Waiting
            printf("P1: sending a message to P2\n");                  
            kill(pid2, SIGUSR1);//<! Sending a message
            wait(&l);//<! Waiting for the end of a child process
            printf("P1: sending a message to P0\n");
            ms_to_write.num = getpid();//<! Getting self idn
            strcpy(ms_to_write.mes,"P1: process finished");
            write(fd[1], &ms_to_write, sizeof(ms_to_write));//<! Send a message in the pipe        
            exit(0);
        }
    }
    else//<! P0 section
    {
        read(fd[0], &ms_to_write, sizeof(ms_to_write));//<! Read a message
        printf("P0: received a message: ");
        printf("<<%s>>\n", ms_to_write.mes);
        read(fd[0], &ms_to_write, sizeof(ms_to_write));//<! Read a message
        printf("P0: received a message: ");
        printf("<<%s>>\n", ms_to_write.mes);
        read(fd[0], &ms_to_write, sizeof(ms_to_write));//<! Read a message
        printf("P0: received a message: ");
        printf("<<%s>>\n", ms_to_write.mes);
        wait(&l);//<! Waiting for the end of a child process
        printf("P0: finishing the programme\n\n");
    }
    return 0;    
}
