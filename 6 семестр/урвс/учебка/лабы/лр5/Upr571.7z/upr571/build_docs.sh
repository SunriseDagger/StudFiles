#!/bin/sh

doxygen upr570.cfg
