#!/bin/sh
g++ -o upr570 sources/main.cpp
