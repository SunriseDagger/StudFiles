#include<signal.h>
#include<stdio.h>
#include<fcntl.h>
#define N 10
union data
{ float x;
  int m;
} d;
int main()
{ int i,fd2,stop,pid;
  FILE *fd1;
  float s,h;
  char str[32];
  mknod("pipe",010666,0);
  fd2=open("pipe",O_RDWR);
  puts("Parent: creating child process");
  if (!(pid=fork()))
  { execl("./laba5a","laba5a",0); }
  sleep(1);
  puts("Parent: sending signal 1");
  kill(pid,SIGUSR1);
  fd1=fopen("file1","r");
  while (fscanf(fd1,"%f",&d.x)!=EOF)
  { printf("Parent: read %f\n",d.x);
    h=1; s=d.x;
    for (i=1;i<=N;i++) { h*=d.x*d.x; s+=h/(2*i+1); }
    d.x=s;
    printf("Parent: write %f\n",d.x);
    for(i=0;i<32;i++)
    { str[i]=(d.m%2)+'0';
      d.m/=2;
    }
    write(fd2,str,32);
  }
  strcpy(str,"stop");
  write(fd2,str,32);
  fclose(fd1);
  close(fd2);
  sleep(1);
  puts("Parent: sending signal 2");
  kill(pid,SIGUSR2);
  wait(&i);
  return 0;
}