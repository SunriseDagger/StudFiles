#include<stdio.h>
#include<signal.h>
#include<math.h>
#include<fcntl.h>
#include<string.h>

void potomok[C()
{ char c[20];
  double y;
  FILE *stream;
  
  printf("\nEst signal...");
  stream=fopen("qwe","r");
 while (strcmp("STOP",c)!=0)
 { if(fscanf(stream,"%s",&c)!=-1)
                  printf("\n%s",c);
   }
 
 }

