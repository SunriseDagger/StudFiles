#include <stdio.h>
#include <stdlib.h>

int main(int cArgs, char *args[])
{
	int cLevels = 0;
	int i;
	pid_t pids[2] = {-1, -1};
	char strLevel[10];

	// check arguments
	if (cArgs < 2)
	{
		fprintf(stderr, "Using: %s <number of levels>\n", args[0]);
		exit(1);
	}

	// convert first argument from string to int
	cLevels = atoi(args[1]);
	if (cLevels < 1 || cLevels > 5)
	{
		puts("invalid number of levels, must be between 1 and 5");
		exit(1);
	}

	fprintf(stderr, "level %s: running normally\n", args[1]);

	if (cLevels != 1)
	{
		// convert number of levels for created processes to strings
		sprintf(strLevel, "%d", cLevels - 1);

		// create two children
		for (i = 0; i < 2; i++)
		{
			pids[i] = fork();
			if (pids[i] == -1)
			{
				perror("error forking");
				break;
			}
			else if (pids[i] == 0)
			{
				fprintf(stderr, "level %s: running process #%d...\n", args[1], i);
				execl(args[0], args[0], strLevel, 0);
				perror("error running new process");
				exit(1);
			}
		}

		// waits for children to terminate
		for (i = 0; i < 2 && pids[i] != -1; i++)
		{
			fprintf(stderr, "level %s: waiting process #%d to terminate...\n", args[1], i);
			if (waitpid(pids[i]) == -1)
				perror("error waiting for process to terminate");
			else
				fprintf(stderr, "level %s: process #%d terminated\n", args[1], i);
		}
	}

	fprintf(stderr, "level %s: exit\n", args[1]);
	exit(0);
}
