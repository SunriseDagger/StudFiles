#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>

struct data
{
    int 	pidproc;
    char 	message[40];
};

int main()
{
    int 	pid, pid_s;
    int 	fildes[2];
    int 	time, flag;	
    data 	dat1;

    pipe(fildes);
    
    if( (pid = fork()) == 0)
    {
    	printf("Son\n");
	pid_s = fork();
	if(pid_s == 0)
	{
	    printf("Vnuk\n");
	    dat1.pidproc = getpid();
	    printf("Pid = %d\n", dat1.pidproc);
	    strcpy(dat1.message, "I am vnuk\n");
	    flag = write(fildes[1], &dat1, sizeof(data));
	    if ( flag == -1 ) 
		printf("Error: Canal vnuk-father...\n");
	}
	else
	{
	    dat1.pidproc = getpid();
	    printf("Pid = %d\n", dat1.pidproc);
	    strcpy(dat1.message, "I am son\n");
	    flag = write(fildes[1], &dat1, sizeof(data));
	    if ( flag == -1 )
		printf("Error: Canal son-father...\n");
	    wait(&time);
	}
    }
    else
    {
	wait(&time);
	for( int i = 0; i < 2; i++ )
	{
	    read(fildes[0], &dat1, sizeof(data));
	    printf("Father said %d %s\n", dat1.pidproc, dat1.message);
	}
    }
}