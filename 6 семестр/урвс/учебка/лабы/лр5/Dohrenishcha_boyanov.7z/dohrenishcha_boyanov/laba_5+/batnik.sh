#!/bin/bash
echo "--------------------Compiling...---------------------"
rm main.exe
g++ main.cpp -o main.exe
echo "--------------------O'k...---------------------------"
