#include <iostream>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <cstdlib>
#include <signal.h>
#include <sys/wait.h>


using namespace std;

int got1 = 0, got3 = 0;

void sigfunc1(int signum)
{
    got1++;
    signal(SIGUSR1, sigfunc1);
}

void sigfunc3(int signum)
{
    got3++;
    signal(SIGUSR2, sigfunc3);
}

    
int main(int argc, char*  argv[])
{
    int k0[2], k1[2], k2[2], pid1, pid2, pid3, status, i1, i2;
    char arg00[44], arg1[40], arg01[44], arg02[44];
    int count = 0;
    cout<<"Main process created 3 channels"<<endl;
    pipe(k0);//special canal
    pipe(k1);
    pipe(k2);
    
    if(!fork())/*son process pid1 of main process*/
    {	
	//-----------------------------------------------------
	if(!(pid3=fork()))/*son of proces pid1 - process pid3*/
	{
	    pid1 = getppid();
	    pid3 = getpid();
	    cout<<"Son process(pid1) "<<pid1<<" created a son process(pid3) "<<pid3<<endl;
	    cout<<" Son process(pid3) "<<pid3<<" send a signal for pid1"<<endl; 
	    fflush(0);
	    sleep(1);
	    kill(pid1, SIGUSR1);//send signal to p1
	    signal(SIGUSR2, sigfunc3);
	    /* waiting for signal*/
	    while(!got3)sleep(1);
	    /*waiting for data from pid1 & pid2*/
	    cout<<"Son process(pid3) "<<pid3<<" is starting to wait data from pid1 & pid2 throught k2 channel"<<endl;
	    fflush(0);
	    while(count!=2)
	    {
		if(read(k2[0],&arg00,45)) {
		count++;
		cout<<"Son process(pid3) "<<pid3<<" got data throught k2 channel: "<<arg00<<endl;
		fflush(0);
		}
		if(read(k2[0], &arg01, 45)){
		 count++;
		 cout<<"Son process(pid3) "<<pid3<<" got data throught k2 channel: "<<arg01<<endl;
		 fflush(0);
		 }
	    }
	    cout<<"Son process(pid3) "<<pid3<<" is preparing data for main process"<<endl;
	    fflush(0);
	    /*prepare data*/
	    sprintf(arg02,"%d",pid3);
	    sprintf(arg1,"%s","Message from third of the son processes");
	    strcat(arg02, arg1);
	    write(k1[1],&arg00, 45);
	    write(k1[1],&arg01, 45);
	    write(k1[1],&arg02, 45);
	    cout<<"Son process(pid3) "<<pid3<<" send data for main process"<<endl;
	    fflush(0);
	    exit(0);
	}
	//---------------------------------------------------------
	pid1 = getpid();
	cout<<"Main process "<<getppid()<<" created a son process(pid1) "<<pid1<<endl;
	fflush(0);
	signal(SIGUSR1, sigfunc1);
	/* waiting for signal*/
	while(!got1)sleep(1);
	cout<<"Son process(pid1) "<<pid1<<" is preparing data for sending throught k2 channel"<<endl;
	fflush(0);
	/*prepare data for channel k2*/
	sprintf(arg00,"%d",pid1);
	sprintf(arg1,"%s","Message from first of the son processes");
	strcat(arg00, arg1);
	write(k2[1],&arg00, 45);//send data in k2
	
	cout<<"son process(pid1) "<<pid1<<" send to p2 pid3 throught synhronize channel k0"<<endl;
	fflush(0);
	/*send p2 throught k0 signal for p3*/
	write(k0[1],&pid3, sizeof(int));
	cout<<"Son process(pid1) "<<pid1<<" is starting to wait for exiting his son(pid3) "<<pid3<<endl;
	fflush(0);
	//if((i1=wait(&status))!=pid3)
	//{ 
	    i1 = wait(NULL);
	    cout<<"Son process(pid3) "<<i1<<" is exited so process(pid1) "<<pid1<<" is exiting"<<endl;
	    fflush(0);
	    exit(0);/* wait(pid3)->exit(1)*/
	//}
    }else{//----------------------------------------------------------
	    if(!fork())/*son process pid2 of main process*/
	    {
	    pid2 = getpid();
	    cout<<" Main process "<<getppid()<<" created a son process(pid2) "<<pid2<<endl;
	    fflush(0);
	    /*waiting for data from p1 throught k0*/
	    cout<<"Son process(pid2) "<<pid2<<" is waitig number of pid3  from synhronize channel k0"<<endl; 
	    fflush(0);
	    while(!read(k0[0],&pid3,sizeof(int)))	
    	    /*prepare data for channel k2*/
	    cout<<"Son process(pid2) "<<pid2<<" is preparing data to send for pid3 throught k2 channel"<<endl;
	    fflush(0);
	    sprintf(arg00,"%d",pid2);
	    sprintf(arg1,"%s","Message from second of the son processe");
	    strcat(arg00, arg1);
	    write(k2[1],&arg00, 45);//send data in k2
	    cout<<"Son process(pid2) "<<pid2<<" send a signal to process(pid3) "<<pid3<<endl;
	    fflush(0);
	    /*send p3 signal*/
	    sleep(1);
	    kill(pid3,SIGUSR2);
	    
	    exit(0);	
	    }else
		{
		    /*main process*/
    
		    while(count!=3)
		    {
			if(read(k1[0],&arg00, 45))
			{
			    cout<<"Result number "<<count<<": "<<arg00<<endl;
			    count++;
			}
		    }
		    cout<<"Main process is waiting for exiting all his son process(pid1) &(pid2) "<<endl;
		    i1 = wait(&status);
		    cout<<"First son process "<<i1<<" exited"<<endl;
		    i2 = wait(&status);
		    cout<<"Second son process "<<i2<<" exited too, so main process is exiting "<<endl;
    		    exit(0);/* wait(pid1&pid2)->exit(1)*/	
		}
	 }
}


