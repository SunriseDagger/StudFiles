#include <cstdlib>
#include <stdio.h>
#include <iostream>
#include <fcntl.h>
#include <unistd.h>

using namespace std;

int main(int argc, char *argv[])
{
    char arg0[44], arg1[40];
    int pid;
    if(!fork())
    {
	pid = getpid();
	sprintf(arg0,"%s",pid);
	sprintf(arg1,"%s", "Message from first of the son processes");
	strcat(arg0, arg1);
	cout<<"word= "<<arg0<<endl;
    }else cout<<"pid "<<pid<<endl;
    cout<<"main"<<endl;
}

