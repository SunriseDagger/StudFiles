#include<signal.h>
#include<unistd.h>
#include<stdio.h>

union BinaryData
{
  float FloatValue;
  int IntegerValue;
};

int bin2int (char[]);

int main(int argc ,char** argv)
{
  union BinaryData f;
  int ppid=getppid(),fifo[2];
  char buf[33];
  sscanf(argv[1],"%d",&fifo[0]);
  sscanf(argv[2],"%d",&fifo[1]);
  kill(ppid,SIGUSR1);
  while (strcmp(buf,"stop"))
    if 	((read(fifo[0],buf,32)!=0)&&(strcmp(buf,"stop")))
    {
      f.IntegerValue=bin2int(buf);
      printf("-==%f==-\n",f.FloatValue);
    }
  return 0;
}
int bin2int (char BinaryValue[33])
{
  int i,PowerOf2=1,IntegerValue;
  IntegerValue=0;
  for (i=0;i<32;i++)
  {
    if (BinaryValue[31-i]=='1')
      IntegerValue+=PowerOf2;
    PowerOf2*=2;
  }
  return IntegerValue;
};