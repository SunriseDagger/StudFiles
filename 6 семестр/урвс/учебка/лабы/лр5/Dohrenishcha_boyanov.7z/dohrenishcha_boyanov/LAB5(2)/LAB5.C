#include<math.h>
#include<unistd.h>
#include<signal.h>

union BinaryData
{
  float FloatValue;
  int IntegerValue;
};

void int2bin (int ,char[]);
void SigHandler(int SigNumber){};

int main()
{
  union BinaryData f;
  int pid,i,j,ppid,status,start=SIGUSR1,fifo[2],N;
  char buf1[33],param1[10],param2[10];
  float x,PoweredX;

  signal(SIGUSR1,SigHandler);
  printf ("Enter interations quantity->");
  scanf ("%d",&N);
  printf ("Enter X value->");
  scanf ("%f",&x);
  if ((x<0)||(x>M_PI))
  {
    printf ("Value of X must be from 0 to PI\n");
    return 1;
  }
  if (pipe(fifo)==-1)
  {
    printf("Can not create a fifo pipe\n");
    return 1;
  }
  sprintf(param1,"%d",fifo[0]);
  sprintf(param2,"%d",fifo[1]);
  pid=fork();
  if (pid==-1)
  {
    printf("Error:fork\n");
    return 1;
  }
  if (pid==0)
  {
    execl("./lab51","lab51",param1,param2,0);
    printf("Can't create daughter process\n");
    return 1;
  }
  else
  {
    pause();
    f.FloatValue=PoweredX=x;
    int2bin(f.IntegerValue,buf1);
    write(fifo[1],buf1,32);
    for (i=1;i<N;i++)
    {
      PoweredX*=x*x;
      f.FloatValue=PoweredX/(2*i+1);
      int2bin(f.IntegerValue,buf1);
      write(fifo[1],buf1,32);
    }
    strcpy(buf1,"stop");
    write(fifo[1],buf1,32);
//    wait (&status);
    return 0;
  }
};
void int2bin (int IntegerValue,char BinaryValue[33])
{
  int i;
  unsigned int mask=1;
  for (i=31;i>=0;i--)
  {
    if (IntegerValue & (int)1)
      BinaryValue[i]='1';
    else
      BinaryValue[i]='0';
    IntegerValue=IntegerValue>>1;
  }
  BinaryValue[32]='\0';
};
