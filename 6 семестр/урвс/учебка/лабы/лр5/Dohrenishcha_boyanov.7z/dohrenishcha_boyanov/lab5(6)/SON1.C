#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>
#include<sys/types.h>
int m;

static void run(int signo)
{
 int f,l,m,j;
 FILE *res;
 float s;
 struct stat info;
 f=open("file",O_RDONLY);
 res=fopen("result","w");
 l=1;
 for(;;)
   {j=stat("file",&info);
    if(info.st_size>=4*l)
      {read(f,&s,sizeof(s));
       if(s==-100)break;
       fprintf(res,"f(%f*pi)=%f\n",(l-1.0)/m,s);
       l++;
      }
    }
  fclose(res);
  close(f);
  exit(0);
}
void main(int argc,char *argv[])
{
sscanf(argv[1],"%ld",&m);
signal (SIGINT, run);
printf("%s","Wait for signal");
pause();
exit(0);
}