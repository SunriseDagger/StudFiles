#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>
#include<sys/types.h>
#define pi 3.14159265
int fdchild[2];
char buf1[20],buf2[20];

int main(int argc,char *argv[])
{
 int f1;
 int i,j,k,n,m,st;
 pid_t pid,pid1;
 float x,y,s;
 if(argc!=1)
 {printf("No parameters expected\n");
  exit(0);
 }

 if(pipe(fdchild) )//try to creat the pipe
  { perror("Cannot creat a pipe\n");
    exit(1);
  }
 switch (pid=fork())
  {   case -1:perror("Error in call FORK()\n");exit(1);break;
      case  0:printf("--- Child process---\n");   //child process  
              read(fdchild[1],buf2,20);
              execl("./son","Son",buf2,0);
	      perror("Error executing program son");
	      exit(1);
	      break;
      default:
              printf("--- Father process---\n");
              
	      printf("Input n- for sum for i=1 to n\n");scanf("%d",&n);

              printf("Input m- how many points on the interval [0;pi]\n");scanf("%d",&m);

	      f1=open("file",O_WRONLY|O_CREAT,0644);
	      for(i=0;i<m+1;i++)
                { x=(i+0.0)*pi/m;
                  y=x;
                  s=x;
		  for(k=1;k<=n;k++)
                    { s=s*x*x;
                      y=y+s/(2*k+1);
                      printf("s=%f,y=%f",s,y);
                    };
                  printf("\n");
                  write(f1,&y,sizeof(y));
                 };
              y=-100;
              write(f1,&y,sizeof(y));
              close(f1);
	      sprintf(buf1,"%ld",m);
	      write(fdchild[0],buf1,20);
	     kill(pid,SIGINT); 
	     if((pid=wait(&st))==-1)
               {perror("Error in call WAIT()");exit(1);}
              printf("Process #%d died with code %d\n",pid,st);
              exit(0);
  }
}