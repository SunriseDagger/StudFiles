#include <stdio.h>
#include <math.h>
#include <signal.h>
#include <unistd.h>

int main(void)
{
 int n;
 double pi,x1,y=0.16666666666666;
 printf("proc2 vip pi\n");
 x1=1+y;
 n=2;
 while(y>0.00000000000001)
 {n=n+2;
 y=(n-1)*(n-1)*y/(n*(n+1));
 x1=x1+y;
 }
 pi=2*x1;
 printf("pi=%f\n",pi);
 write(1,(char*)&pi,sizeof(pi));
 pause();
}
