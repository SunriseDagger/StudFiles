#include <sys/stat.h>
#include <sys/types.h>
#include <stdio.h>
#include <math.h>
#include <signal.h>
#include <fcntl.h>
#include <unistd.h>
int pid1,pid2;
void sigcatch1()
{
printf("sig1\n");
signal(SIGUSR1,sigcatch1);
}
void sigcatch2()
{
printf("sig2\n");
signal(SIGUSR2,sigcatch2);
}


main()
{
  int fd[2],pid1,pid2,fd1;
  double x,pi,c,f;
//  fd1=open("./tmp",O_RDWR|O_CREAT|O_TRUNC,S_IRUSR|S_IWUSR);
//  printf("Vvod x\n");
//  scanf("%lf",&x);
//  printf("%f\n",x);
//  write(fd1,&x,sizeof(x));
  signal(SIGUSR1,sigcatch1);
  signal(SIGUSR2,sigcatch2);
  pipe(fd);
  if((pid1=fork())==0)
  {
   double x;  
   signal(SIGUSR1,sigcatch1);
   signal(SIGUSR2,SIG_IGN);
   pause();
   printf("start process 1\n");
   close(1);
   dup(fd[1]);
   close(fd[1]);
   close(fd[0]);
//   lseek(fd1,0,0);
//   read(fd1,&x,sizeof(x));
//   printf("%f\n",x);  
    execl("proc1","proc1",NULL);
	exit(0);
	}
    else
     {
  if((pid2=fork())==0)
        {
	signal(SIGUSR2,sigcatch2);
	signal(SIGUSR1,SIG_IGN);
	pause();
	printf("start prosecc 2 \n");
	close(1);
	dup(fd[1]);
	close(fd[1]);
	close(fd[0]);
	execl("proc2","proc2",NULL);
	exit(0);
	}
}
sleep(5);
kill(pid1,SIGUSR1);
close(0);
dup(fd[0]);
close(fd[1]);
close(fd[0]);
sleep(5);
read(0,(char *)&x,sizeof(x));	
read(0,(char *)&c,sizeof(c));
kill(pid2,SIGUSR2);
sleep(5);
 read(0,(char *)&pi,sizeof(pi));
  f=(1-c)/(pi*x*x);
  printf("pi=%f\n",pi);
  printf("cos(x)=%f\n",c);
  printf("F=%f\n",f);
  kill(pid1,SIGUSR1);
  kill(pid2,SIGUSR2);
 }
  
  
  	
	
	

