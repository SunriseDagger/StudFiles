#include <stdio.h>
#include <signal.h>
#include <math.h>
#include <unistd.h>

int main()
{
  
  double c,y,x;
  int n=1,k=1;
//  fd1=atoi(argv[1]);
//  x=atof(argv[1]);
//  lseek(fd1,0,0);
//  read(fd1,&x,sizeof(x));
  printf("vvod x\n");
  scanf("%lf",&x);
//  printf("x1=%f\n",x);
  y=x*x/2;
  c=1-y;
  while(y>0.0001)
   {n=n+2;
    y=y*x*x/(n*(n+1));
    if(k==1)
      {c=c+y;
       k++;
      }
      else
       {c=c-y;
       k--;
       }
    };
    printf("cd=%f\n",c);
    write(1,(char*)&x,sizeof(x));
    write(1,(char*)&c,sizeof(c));
    pause();
 }
