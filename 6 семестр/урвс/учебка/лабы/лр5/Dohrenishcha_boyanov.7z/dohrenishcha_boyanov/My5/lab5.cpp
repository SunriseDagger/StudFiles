#include <unistd.h> 
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    int nlevels;
    char *temp;
    if (argc != 2)	printf("Error parameter: lab5 <nlevels>\n");
    else
    {	sscanf(argv[1], "%d", &nlevels);
	if (nlevels > 5 || nlevels < 1)
	{	printf("Error parameter: <nlevels> is integer in [1;5]\n");
	        exit(0);
	}
	nlevels--;
	printf("Process %d at level %d\n", getpid(), nlevels);
	fflush(0);
	if (nlevels>0)
	{	sprintf(temp, "%d", nlevels);
		sleep(1);
		execl("node", temp, 0);
	}
    }
}
