#include <unistd.h> 
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
    int level, pid, child;
    char *temp;
    sscanf(argv[0], "%d", &level);
    if ((pid=fork())==-1)
    {	printf("\tProcess %d can't create new process\n",getpid());
	exit(1);
    }
    else
    	if (!pid)
	{   level--;
	    printf("Process %d, created by %d, at level %d starts working\n", getpid(), getppid(),level);
	    fflush(0);
	    if ( !level )
	    {	printf("Process %d is the last in the chain\n", getpid());
	        fflush(0);
		exit(0);
	    }
	    sprintf(temp, "%d", level);
	    sleep(1);
	    execl("node", temp, 0);
	    exit(0);
	}
    if ((pid=fork())==-1)
    {	printf("\tProcess %d can't create new process\n",getpid());
	exit(1);
    }
    else
    {	if (!pid)
	{   level--;
	    printf("Process %d, created by %d, at level %d starts working\n", getpid(), getppid(),level);
	    fflush(0);
	    if ( !level )
	    {	printf("Process %d is the last in the chain\n", getpid());
		fflush(0);
		exit(0);
	    }
	    sprintf(temp, "%d", level);
	    sleep(1);
	    execl("node", temp, 0);
	    exit(0);
	}
	else
	{   child = wait(NULL);
	    printf("Process %d, created by %d, stopped working\n", child, getpid());
	    fflush(0);
	    child = wait(NULL);
	    printf("Process %d, created by %d, stopped working\n", child, getpid());
	    fflush(0);
	    printf("Process %d stops working\n", getpid());
	    fflush(0);
	    exit(0);
	}
    }
}
