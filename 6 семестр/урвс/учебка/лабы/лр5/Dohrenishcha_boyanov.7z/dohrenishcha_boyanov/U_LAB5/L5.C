#include<stdio.h>
#include<signal.h>
#include<math.h>
#include<fcntl.h>
#include<string.h>

int pot()
{ printf("\nDo pot ");
execl("pot.out",0);
printf(" Posle pot");
}

int main()
{ int N,k=1,pid,d;
  double x=0,x1=0,slx,xp,xp1;
  FILE * stream=fopen("qwe","w");

 pid=fork();
 if (pid==0) { signal(SIGINT,(int)pot); pause(); exit(1);}

 printf("\n Do signal");
// kill(pid,SIGINT);
// printf("\n Posle signal");
 
for(N=1;N<=9;N++)
  { slx=3.14*k/N;
    for(k=1;k<=N;k++)
     x=pow(slx,2*k+1)/(2*k+1);
     
  fprintf(stream,"%f\n",x);
  }
  fprintf(stream,"STOP");
  

  fclose(stream);

  kill(pid,SIGINT);
  printf("\n Posle signal");
  wait(&d); 
// del potomok
  exit(pid); 
  
  return(1);
}