#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <math.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
void sign(int a)
{
;
}
void main()
{
   int K1[2],K0[2],pidP3,N,inf,pidP1,pidP2,i,pidP0;
   printf("main process begin\n");
   /*open canal K1 for reading and writing*/
   mkfifo("infkan",010666);
   mkfifo("sinkan",010666);
   K1[0]=open("infkan",O_RDWR);
   K1[1]=open("infkan",O_RDWR);
   K0[0]=open("sinkan",O_RDWR);
   K0[1]=open("sinkan",O_RDWR);
   printf("born K1, K0\n");
   if (fork()==0)
   {
      printf("process P1 begin\n");
      pidP1=getpid();
      if (fork()==0)
      {
         printf("process P3 begin\n");
	 N=3;
         inf=333;
	 pidP3=getpid();
         write(K1[1],&N,4);
         write(K1[1],&inf,40);
	 printf("P3 wrote in K1\n");
         printf("P3 send sign to P1\n");
         kill(pidP1,30);
	 sleep(5);
	 signal(31,sign);
	 printf("P3 get sign from P2\n");
	 N=3;
	 inf=444;
	 write(K1[1],&N,4);
	 write(K1[1],&inf,40);
	 printf("P3 wrote in K1\n");
	 
      }
      else
      {  
         signal(30,sign);
	 sleep(10);
         printf("P1 get signal from P3\n");
	 N=1;
	 inf=111;
	 write(K1[1],&N,4);
	 write(K1[1],&inf,40);
         printf("P1 wrote in K1\n");
  	 write(K0[1],&pidP3,4);
	 printf("P1 wrote pidP3 in K0\n");
         sleep(15);
	 printf("P1 wait P3\n");
         wait(&pidP3);
      }	
        
   }
   else
   {
      if (fork()==0)
      {
         sleep(5);
         printf("begin P2\n");
         read(K0[0],&pidP3,4);
	 printf("P2 take pidP3 from K0\n");
	 N=2;
 	 inf=222;
	 write(K1[1],&N,4);
	 write(K1[1],&inf,40);	 
	 printf("P2 wrote in K1\n");
	 kill(pidP3,31);
         printf("P2 send sign to P3\n");
      }
      else
      {  sleep(10);
         printf("P0 reading from K1\n");
         for (i=1;i<5;i++)
         {
	    N=0;
	    inf=0;
            read(K1[0],&N,4);
	    read(K1[0],&inf,40);
	    printf("%d\n",N);
	    printf("%d\n",inf);
	} 
//      }

    sleep(10);   
    printf("P0 wait P1\n");
    wait(&pidP1);
    printf("P0 wait P2\n");
    wait(&pidP2);	
    pidP0=getpid(); 
   }
}	
   close(K1[0]);
   close(K1[1]);
   close(K0[0]);
   close(K0[1]);
   kill(pidP0,1);
}

