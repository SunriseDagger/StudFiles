#include <stdio.h>
#include <ctype.h>
#include <string.h>
#define WORD     0
#define IGNORE   1

char     *Words[BUFSIZ/2];
int      WordCount;

void PrintWords(int wc,char match)
{  register int    ix;
   register char   *cp;
   for (ix=0; ix < wc; ix++)
   { cp = Words[ix];
     while ((*cp) && (*cp++ != match))
       if (*cp == match)  printf("%s \n", Words[ix]);
   }
}

int GetWords (char *buf)
{ register char    *cp;
  int      end = strlen(buf);
  register int  wc = 0;
  int      state = IGNORE;
  for (cp = &buf[0]; cp < &buf[end]; cp++)
  { switch(state) {
     case IGNORE: if (!isspace(*cp)) { Words[wc++] = cp;
                                       state = WORD;
                                     }
                  break;
     case WORD:   if (isspace(*cp)) { *cp = '\0';
                                      state = IGNORE;
                                    }
                  break;
                  }
  }
  return wc;
}

int  main(int argc, char *argv[])
{ char buf[BUFSIZ], match;
  if (argc < 2) match = '\0';
           else match = *++argv[1];
  while(gets(buf) != (char *)NULL) {
              WordCount = GetWords(buf);
              PrintWords(WordCount, match);
                                    }
  return(0);   /* Return success to the shell. */
}
