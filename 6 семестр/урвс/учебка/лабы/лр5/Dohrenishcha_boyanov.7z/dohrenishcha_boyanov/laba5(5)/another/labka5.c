#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<stdio.h>
#include<string.h>
#include<signal.h>

struct info
{
  int name;
  char inf[40];
} var;

int flag=1; 

void sign()
{
signal(SIGINT,sign);
flag=0;
}
main()
{ 
  int canal[2],pd1,pd2,i;
  
  printf("Process0:Begin\n");
   
  signal(SIGINT,sign); 
  printf("Process0: Creat canal\n");
  pipe(canal);
  				
  if((pd1=fork()) == 0)
  {  printf("Process1: Start\n");
     printf("Process1: Cozdanie processa2\n");
     
     if((pd2=fork()) == 0)
      {  printf("Process2: Start\n");
         printf("Process2: Ogidaet  signal\n");
         while(flag) pause();     

	 strcpy(var.inf, "Info ot 2nd process N1!!!!");
	 var.name=(int)getpid ();
	 printf("Process2: Posilaet info v canal\n");
	 write(canal[1], &var, sizeof var);
	 
         printf("Process2: Posilaem signal to Process1\n");
         kill(pd1,SIGINT);
	 printf("Process2: Exit\n");
         exit(0);
       }
      else
       {         
		 strcpy(var.inf, "Info ot 1st process N1!!!!");
		 var.name=(int)getpid ();
		 printf("Process1: Posilaem info v  canal\n");
		 write(canal[1], &var, sizeof var);
		 
	         printf("Process1: Posilaem signal to process2\n");
                 kill(pd2,SIGINT);
                 printf("Process1: Ogidaem signal\n");
                 while (flag) pause(); 
		 
		 strcpy(var.inf, "Info ot 1st process N2!!!!");
		 var.name=(int)getpid ();
		 printf("Process1: Posilaem info v canal\n");
		 write(canal[1], &var, sizeof var);
                 wait();
        	 printf("Process1: Exit\n");
                 exit(0);
       }         
  }             
  else
  {
    printf("Process0: Start reading  info\n"); 

   for(i=0;i<3;i++)
   {      
    read (canal[0], &var, sizeof var);
    printf ("Process0: %ld send %s\n\n", var.name, var.inf);
   }
    wait();
    printf("Process0: Exit\n");
   }
} 
