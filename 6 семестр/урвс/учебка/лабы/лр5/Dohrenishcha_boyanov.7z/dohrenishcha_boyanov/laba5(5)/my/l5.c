#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

struct Tcell {
    int pid;
    char data[40]; } cell;

void OnSignal (){;}

int main() {
    int pid1,pid2,pipe1[2],pipe2[2];

    printf ("\n\n\n Parent: create pipe1 and pipe2.\n");
    pipe(pipe1);
    pipe(pipe2);

    printf (" Parent: create Child1.\n");			// create child 1
    pid1=fork ();

    if (pid1 == 0) {
        printf (" Child1: I'm waiting for any signal.\n");	
        signal (SIGINT, OnSignal);
	pause ();						// wait for signal
	sleep(1);						// let Child2 to finish
        printf (" Child1: I got a signal!\n");

	read(pipe1[0],&cell,sizeof cell);			// read data from pipe1
	write(pipe2[1],&cell,sizeof cell);			// and add it into pipe2
        printf (" Child1: I read and sent Child2's data into pipe2. \n");	
	
	strcpy (cell.data, "some data from Child1");
        cell.pid=getpid ();
        printf (" Child1: I sent my data into pipe2.\n");
        write (pipe2[1],&cell, sizeof cell);			// write it's data into pipe2

        printf (" Child1: I completed.\n\n");
	exit (0); }

    printf (" Parent: create Child2.\n\n");
    pid2 = fork ();						// create child 2

    if (pid2 == 0) {
        strcpy (cell.data, "some data from Child2");
	cell.pid=getpid ();
        printf (" Child2: I sent data into pipe1.\n");
        write (pipe1[1],&cell,sizeof cell);			// write data into pipe1

        printf (" Child2: I sent signal to Child1.\n");
	kill (pid1, SIGINT);					// send signal

        printf (" Child2: I completed.\n\n");
	exit (0); }

    wait (0);
    wait (0);

    printf (" Parent: I'm reading data from pipe2...\n\n");
    read (pipe2[0],&cell, sizeof cell);				// read the first data
    printf ("\t child '%d' sent: '%s'\n", cell.pid, cell.data);
    read (pipe2[0],&cell,sizeof cell);				// read the second data
    printf ("\t child '%d' sent: '%s'\n\n", cell.pid, cell.data);

}

