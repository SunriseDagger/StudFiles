#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <math.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
void sign()
{
;
}
void main()
{
   int K1[2],K0[2],pid,N,infP3;
   printf("main process begin\n");
   /*open canal K1 for reading and writing*/
   mkfifo("infkan",010666);
   mkfifo("sinkan",010666);
   k1[0]=open("infkan",O_RDWR);
   k1[1]=open("infkan",O_RDWR);
   k0[0]=open("sinkan",O_RDWR);
   k0[1]=open("sinkan",O_RDWR);
   if (fork()==0)  //born P1
   /*main process*/
      {
      if (fork())  //born P2
      /*main process */
	 {
	 read
	 }
      else
	 { /*begin P2*/
	 read(K0[0],&pidP3,4);
	 N=2;
	 inf=333;
	 write(K1[1],&N,4);
	 write(K1[1],&inf,40);
	 printf("infP2 wrote\n");
	 kill(pidP3,31);
	 printf("P2 send signal to P3\n");
	 }
   else
      /*begin P1*/
      {
      pidP1=getpid();
      signal(30,sign);
      N=1;
      inf=222;
      write(K1[1],&N,4);
      write(K1[1],&inf,40);
      printf("infP1 wrote\n");
      write(K0[1],&pidP3,4);
      printf("pid P3 wrote\n");
      sleep(5);
      kill(pidP3,1);
      printf("process P3 died:-(\n");
      wait(&N);
      if (fork())  //born P3
	 { /*continue P1*/
	 }
      else
	 { /*begin P3*/
	 pidP3=getpid();
	 N=3;
	 inf=111;
	 write(K1[1],&N,4);
	 write(K1[1],&inf,40);
	 printf("1.infP3 wrote\n");
	 kill(pidP2,30);
	 printf("P3 send signal to P2\n");
	 signal(31,sign);
	 inf=444;
	 write(K1[1],&N,4);
	 write(K1[1],&inf,40);
	 printf("2.infP3 wrote");
	 }
      }
      }
   }
   close(K1[0]);
   close(K1[1]);
   close(K0[0]);
   close(K0[1]);
}