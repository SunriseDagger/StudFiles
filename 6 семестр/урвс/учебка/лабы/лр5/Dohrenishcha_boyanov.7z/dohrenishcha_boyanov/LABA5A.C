#include<signal.h>
#include<stdio.h>
#include<fcntl.h>
union data
{ float x;
  int m;
} d;
void recieve1(int signum) { puts("Child : got signal 1"); }
void recieve2(int signum) { puts("Child : got signal 2"); }
int main()
{ int i,fd,stop;
  char str[32];
  stop=0;
  signal(SIGUSR1,&recieve1);
  signal(SIGUSR2,&recieve2);
  pause();
  fd=open("pipe",O_RDWR);
  puts("Child : reading...");
  do
  { read(fd,str,32);
    if (str[0]=='s' && str[1]=='t' && str[2]=='o' && str[3]=='p') stop=1;
    else
    { for (i=31,d.m=0;i>=0;i--) d.m=d.m*2+(str[i]=='1');
      printf("Child : %f\n",d.x);
    }
  } while(!stop);
  pause();
  puts("Child : exit");
  close(fd); 
  return 0;
}
