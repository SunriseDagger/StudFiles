#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <wait.h>

char data[50];

int got1 = 0, got3 = 0;

void sigfunc1(int signum)
{
    got1++;
    signal(SIGUSR1, sigfunc1);
}

void sigfunc3(int signum)
{
    got3++;
    signal(SIGUSR2, sigfunc3);
}

int main()
{
	int pid1,pid2,pid3,pipe1[2],pipe2[2],pipe0[2];
	int count = 0;

	printf("P0: create K1, K2, K0\n");	
	pipe(pipe1);//sozdaem kanali dlya vzaimodeistvia
	pipe(pipe2);
	pipe(pipe0);

	printf("P0: create P1\n"); 	
	pid1 = fork ();
	
	if (pid1 == 0) 
	{
//		signal(SIGINT, OnSignal);
		pid3 = fork();
	
		if(pid3 == 0)
		{
			strcpy(data,"## From P3 data 1/2 ##");
			printf("P3: -- data to K1 --\n");
			write(pipe1[1],&data,sizeof(data));
			printf("P3: send signal to P1\n");
	/*		sleep(1);
			kill(pid1,SIGINT);
			printf("P3: .. waiting for signal ..\n");
			pause();
			sleep(1);
			printf("P3: !! signal !!\n");*/

		//	fflush(0);
			sleep(1);
	    		kill(pid1, SIGUSR1);  //send signal to p1
	    		signal(SIGUSR2, sigfunc3);
	    		/* waiting for signal*/
	    		printf("P3: .. waiting for signal ..\n");		
			while(!got3) sleep(1);
		//	fflush(0);
	    		while(count!=2)
	    		{
				if(read(pipe2[0],&data,sizeof(data)))
				{
					count++;
					printf("P3: -- data from K2 to K1 --\n"); 
					printf ("P3: ++ data from K2: '%s' ++\n", data);						write(pipe1[1],&data,sizeof(data));
					write(pipe1[1],&data,sizeof(data));
				//	fflush(0);
				}
				if(read(pipe2[0],&data,sizeof(data)))
				{
		 			count++;
					printf("P3: -- data from K2 to K1 --\n"); 
					printf ("P3: ++ data from K2: '%s' ++\n", data);
					write(pipe1[1],&data,sizeof(data));
				//	fflush(0);
				}
			}
		//	fflush(0);
	    		printf("P3: -- data to K1 --\n"); 
			strcpy(data,"## From P3 data 2/2 ##");
			write(pipe1[1],&data,sizeof(data));
			printf("P3: XX end P3 XX\n");
			exit(0);
		}
		printf ("P1: creat P3\n");
	//	fflush(0);
		signal(SIGUSR1, sigfunc1);
		/* waiting for signal*/
		printf("P1: .. waiting for signal ..\n");		
		while(!got1) sleep(1);
		
//		pause();
		printf("P1: !! signal !!\n");
		strcpy(data, "##  From P1 data 1/1 ##");
		printf("P1: -- data to K2 --\n");
		write(pipe2[1],&data,sizeof(data));                 
		printf("P1: identifikator P3 to K0\n");
	//	fflush(0);

		write(pipe0[1],&pid3,sizeof(pid3));   
		printf("P1: .. waiting for end P3 ..\n");
		wait(0);
		sleep(1);
		printf ("P1: !! end P3 !!\n");
		printf ("P1: XX end P1 XX\n");
		exit (0);
	}
	printf ("P0: create P2\n");
	pid2 = fork ();

	if (pid2 == 0)
	{
	//	fflush(0);
		printf("P2: .. look at K0 ..\n");
		read(pipe0[0],&pid3,sizeof(int));	
		sleep(1);
		strcpy (data,"##  From P2 data 1/1 ##");
		printf ("P2: -- data to K2 --\n");
		write (pipe2[1],&data,sizeof(data));	
		printf ("P2: send signal to P3\n");
	//	fflush(0);
	    	/*send p3 signal*/
	    	sleep(1);
	    	kill(pid3,SIGUSR2);
	        printf ("P2: XX end P2 XX\n");
		exit (0);
 	}

	printf ("P0: .. look at K1 ..\n");
	while(count!=3)
	{
		if(read(pipe1[0],&data,sizeof(data)))
		{
			printf ("P0: ++ new data: '%s' ++\n", data);				
		    	count++;
		}
	}

/*	wait (0);
	printf ("P0: .. look at K1 ..\n");
	read (pipe1[0],&data,sizeof(data));                             
	
	read (pipe1[0],&data,sizeof(data));                             
	printf ("P0: ++ new data: '%s' ++\n", data);
	read (pipe1[0],&data,sizeof(data));                             
	printf ("P0: ++ new data: '%s' ++\n", data);
	read (pipe1[0],&data,sizeof(data));                             
	printf ("P0: ++ new data: '%s' ++\n", data);*/
	printf ("P0: .. waiting for end P1,P2,P3 ..\n");
    //	wait(0);
    //	wait(0);
	printf ("P0: !! end P1,P2,P3 !!\n");
	printf ("P0: The end.\n");
	exit(0);
}
