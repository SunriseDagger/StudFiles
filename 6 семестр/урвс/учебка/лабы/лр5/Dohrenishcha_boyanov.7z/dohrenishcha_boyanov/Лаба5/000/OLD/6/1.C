#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>
#include <wait.h>

struct record {
    int pid;
    char data[40]; }
     rec;

 void OnSignal(int x)
 {}

int main() {
int pid1,pid2,pipe1[2],pipe0[2],pid3;

printf ("\n\n\n Parent: create pipe1 and pipe2.\n");
pipe(pipe1);//sozdaem kanali dlya vzaimodeistvia
pipe(pipe0);

printf (" Parent: create Child1.\n"); 
signal(SIGINT, OnSignal);             
pid1=fork ();                         // create Child1

if (pid1 == 0) 
{
signal(SIGINT, OnSignal);
printf(" Child1: creat Child3.\n"); 
pid3 = fork();                       // create Child3
if(pid3 == 0)
{
/*P3*/
strcpy(rec.data,"some data from Child3");
rec.pid=getpid();
printf(" Child3: I sent data into pipe1.\n");
write(pipe1[1],&rec,sizeof rec);
printf(" Child3: I sent signal to Child1.\n");
sleep(1);
kill(pid1,SIGINT);
printf(" Child3: I'm waiting for signal.\n");
pause();
sleep(1);
printf(" Child3: I got a signal!\n");

printf (" Child3: I sent data into pipe1.\n"); 
write(pipe1[1],&rec,sizeof rec);

printf(" Child3: I completed.\n\n");
exit(0);
}
/* P1*/
printf (" Child1: I'm waiting for any signal.\n");

pause ();                                         // wait for signal
printf (" Child1: I got a signal!\n");   
strcpy (rec.data, "some data from Child1");
rec.pid=getpid ();
printf (" Child1: I sent my data into pipe1.\n");
write(pipe1[1],&rec,sizeof rec);                 
printf(" Child1: I sent identifikator Child3 into pipe0.\n");
write(pipe0[1],&pid3,sizeof pid3);   
printf(" Child1: I'm waiting the end Child3.\n");
wait(0);
sleep(1);
printf (" Child1: I completed.\n\n");
exit (0);
}
printf (" Parent: create Child2.\n\n");
pid2 = fork ();                         // create Child2
if (pid2 == 0) {
/*P2*/
strcpy (rec.data, "some data from Child2");
rec.pid=getpid ();
printf(" Child2: Opros pipe0.\n");
read(pipe0[0],&pid3,sizeof pid3);
sleep(1);
printf (" Child2: I sent data into pipe1.\n");
write (pipe1[1],&rec,sizeof rec);            // write data into pipe1
printf (" Child2: I sent signal to Child3.\n");

kill (pid3, SIGINT);                           // send signal
printf (" Child2: I completed.\n\n");
exit (0);
 }
//printf(" Parent: I'm waiting the end Child1.\n"); 
wait (0);
//printf(" Parent: I'm waiting the end Child2.\n");
wait (0);
printf (" Parent: I'm reading data from pipe1...\n\n");
read (pipe1[0],&rec, sizeof rec);                             
printf ("\t child '%d' sent: '%s'\n", rec.pid, rec.data);

read (pipe1[0],&rec,sizeof rec);                             
printf ("\t child '%d' sent: '%s'\n", rec.pid, rec.data);

read (pipe1[0],&rec, sizeof rec);
printf ("\t child '%d' sent: '%s'\n",rec.pid,rec.data);

read (pipe1[0],&rec, sizeof rec);
printf ("\t child '%d' sent: '%s'\n",rec.pid,rec.data);
exit(0);
 }
