#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>

struct Tcell {
    int pid;
    char data[40]; } cell;

void OnSignal (){;}

int main() {
    int pid1,pid2,pipe1[2],pipe0[2],pid3;

    printf ("\n\n\n Parent: create pipe1 and pipe2.\n");
    pipe(pipe1);//sozdaem kanali dlya vzaimodeistvia
    pipe(pipe0);

    printf (" Parent: create Child1.\n");			// create child 1
    pid1=fork ();

    if (pid1 == 0) {
    
        printf(" Child1: creat Child3.\n");                    // creat child 3
        pid3 = fork();
	if(pid3 == 0) 
	{
	strcpy(cell.data,"some data from Child3");
	cell.pid=getpid();
        printf(" Child3: I sent data into pipe1.\n");
	write(pipe1[1],&cell,sizeof cell);
	printf(" Child3: I sent signal to Child1.\n");
	kill(pid1,SIGINT);
	printf(" Child3: I'm waiting for any signal.\n");
	signal(SIGINT,OnSignal);
	pause();
	sleep(1);
	printf(" Child3: I got a signal!\n ");
	read(pipe1[0],&cell,sizeof cell);
	printf(" Child3: I read and sent Child2's data into pipe1.\n");
	printf(" Child3: I completed.\n\n");
	exit(0); 	
	}
	
        printf (" Child1: I'm waiting for any signal.\n");	
        signal (SIGINT, OnSignal);
	pause ();						// wait for signal
	sleep(1);						// let Child2 to finish
        printf (" Child1: I got a signal!\n");

	read(pipe1[0],&cell,sizeof cell);			// read data from pipe1
//	write(pipe2[1],&cell,sizeof cell);			// and add it into pipe2
//        printf (" Child1: I read and sent Child2's data into pipe2. \n");	
	printf(" Child: I read Child3's data.\n");

	strcpy (cell.data, "some data from Child1");
        cell.pid=getpid ();
//        printf (" Child1: I sent my data into pipe2.\n");
//        write (pipe2[1],&cell, sizeof cell);			// write it's data into pipe2
        printf (" Child1: I sent my data into pipe1.\n ");
        write(pipe1[1],&cell,sizeof cell);  
        
        printf(" Child1: I sent identifikator Child3 into pipe0.\n ");
        write(pipe0[1],&pid3,sizeof pid3);   //????     
	        
        pause();
	sleep(1);
        printf (" Child1: I completed.\n\n");
	exit (0); }

    printf (" Parent: create Child2.\n\n");
    pid2 = fork ();						// create child 2

    if (pid2 == 0) {
        strcpy (cell.data, "some data from Child2");
	cell.pid=getpid ();
	printf("Child2: opros pipe0.\n");
	read(pipe0[0],&pid3,sizeof pid3);//???

//	read(pipe1[0],&cell,sizeof cell);
        printf (" Child2: I sent data into pipe1.\n");
        write (pipe1[1],&cell,sizeof cell);			// write data into pipe1
    
        printf (" Child2: I sent signal to Child3.\n");
	kill (pid3, SIGINT);					// send signal

        printf (" Child2: I completed.\n\n");
	exit (0); }

    wait (0);
    wait (0);

    printf (" Parent: I'm reading data from pipe1...\n\n");
    read (pipe1[0],&cell, sizeof cell);				// read the first data
    printf ("\t child '%d' sent: '%s'\n", cell.pid, cell.data);
    read (pipe1[0],&cell,sizeof cell);				// read the second data
    printf ("\t child '%d' sent: '%s'\n\n", cell.pid, cell.data);
    read (pipe1[0],&cell, sizeof cell);
    printf ("\t child '%d' sent: '%s'\n\n\n",cell.pid,cell.data);
    read (pipe1[0],&cell, sizeof cell);
    printf ("\t child '%d' sent: '%s'\n\n\n\n",cell.pid,cell.data);    
}

