#include<stdio.h>
#include<stdlib.h>
#include<sys/stat.h>
#include<fcntl.h>
#include<signal.h>
#include<unistd.h>
main(int argc,char *argv[])
{
int fd,help;
unsigned long int i,j,k,l,p;
char str[5];
i=atoi(argv[1]);
//printf("PR 2 %d starts\n",i);
fd=open("fnr",O_RDWR);
help=open("hlp",O_RDWR);
read(fd,&j,sizeof(j));
k=1;
for(l=2;l<j+1;l++)k=k*l;
//if(j==0)k=1;
write(fd,&k,sizeof(k));
close(fd);
p=i+1;
write(help,&p,sizeof(p));
close(help);
//printf("PR 2 %d stops\n",i);
exit(0);
}

