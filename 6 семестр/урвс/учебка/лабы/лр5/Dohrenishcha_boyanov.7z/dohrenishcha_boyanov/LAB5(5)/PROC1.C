#include<stdio.h>
#include<stdlib.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<fcntl.h>
#include<unistd.h>
#include<signal.h>
main()
{
int fd,help;
char str[5];
unsigned long int j,k,l,p;
//printf("PR 1 starts\n");
fd=open("fn",O_RDWR);
help=open("hlp",O_RDWR);
read(fd,&j,sizeof(j));
k=1;
for(l=2;l<j+1;l++)k=k*l;
write(fd,&k,sizeof(k));
close(fd);
p=1;
write(help,&p,sizeof(p));
close(help);
//printf("PR 1 stops\n");
exit(0);
}

