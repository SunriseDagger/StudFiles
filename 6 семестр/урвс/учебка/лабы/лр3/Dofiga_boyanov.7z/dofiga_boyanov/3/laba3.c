/*********************************************
* Control source laba 3
* Author Kulikov I, Tsarapkin V
*********************************************/
#include<stdio.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<sys/types.h>

int HandleFileA,      // descriptor 'fileA'
    HandleFileB,      // descriptor 'fileB'  	
    HandleFileAClone; // descriptor 'fileA' clone
 
int main()
{
 char Message[]="Hello !"; // message for 'fileB'
 char RecvMessage[15];     // recive message
 int count;               // count real read/write symbols
 struct stat BuferFileA;  // struct for file info
 struct stat BuferFileB;
 // Open STDERR, STDIN, STDOUT
 system("clear");
 printf("----- Open standart file ------\n");
 printf("************** Table file ****************************\n");
 printf("** Filename ********** Record in table openfiles *****\n");
 printf("1. STDIN        *                 -                   \n");
 printf("2. STDOUT       *                 -                   \n");
 printf("3. STDERR       *                 -                   \n");
 printf("******************************************************\n");
 printf("\n");
 printf("************** Table open files **********************\n");
 printf("** Filename *** Position *** Record in table stat ****\n");    
 printf("******************************************************\n");    
 printf("\n");
 printf("************** Table stat files **********************\n");
 printf("** Filename *** Inode *** Mode *** Size *** Link *****\n");    
 printf("******************************************************\n");    
 getchar();
 system("clear");
 // Open 'fileA'for read
 HandleFileA=open("fileA",O_RDONLY); 
 if(HandleFileA < 0) { printf("\nError!"); return 1; }
 fstat(HandleFileA,&BuferFileA);
 printf("----- Open fileA for read ------\n");
 printf("************** Table file ****************************\n");
 printf("** Filename ********** Record in table openfiles *****\n");
 printf("1. STDIN        *      -                              \n");
 printf("2. STDOUT       *      -                              \n");
 printf("3. STDERR       *      -                              \n");
 printf("4. fileA        *      1                              \n");
 printf("******************************************************\n");
 printf("\n");
 printf("************** Table open files **********************\n");
 printf("** Filename *** Position *** Record in table stat ****\n");
 printf("1. fileA     *  0 (read)  *  1                        \n");    
 printf("******************************************************\n");    
 printf("\n");
 printf("************** Table stat files **********************\n");
 printf("** Filename *** Inode *** Mode *** Size *** Link *****\n");    
 printf("1. fileA     *  %5d  * %5d  *  %5d  * %5d  \n",
        BuferFileA.st_ino,
	BuferFileA.st_mode,
	BuferFileA.st_size,
	BuferFileA.st_nlink);
 printf("******************************************************\n");    
 getchar();
 system("clear");
 // Open 'fileB' for write
 HandleFileB=open("fileB",O_WRONLY); 
 if(HandleFileB < 0) { printf("\nError!"); return 1; }
 fstat(HandleFileB,&BuferFileB);
 printf("----- Open fileB for write ------\n");
 printf("************** Table file ****************************\n");
 printf("** Filename ********** Record in table openfiles *****\n");
 printf("1. STDIN        *      -                              \n");
 printf("2. STDOUT       *      -                              \n");
 printf("3. STDERR       *      -                              \n");
 printf("4. fileA        *      1                              \n");
 printf("5. fileB        *      2                              \n");
 printf("******************************************************\n");
 printf("\n");
 printf("************** Table open files **********************\n");
 printf("** Filename *** Position *** Record in table stat ****\n");
 printf("1. fileA     *  0 (read)  *  1                        \n");
 printf("2. fileB     *  0 (write) *  2                        \n");    
 printf("******************************************************\n");    
 printf("\n");
 printf("************** Table stat files **********************\n");
 printf("** Filename *** Inode *** Mode *** Size *** Link *****\n");    
 printf("1. fileA     *  %5d  * %5d  *  %5d  * %5d  \n",
        BuferFileA.st_ino,
	BuferFileA.st_mode,
	BuferFileA.st_size,
        BuferFileA.st_nlink);
 printf("2. fileB     *  %5d  * %5d  *  %5d  * %5d  \n",
	BuferFileB.st_ino,
	BuferFileB.st_mode,
	BuferFileB.st_size,
	BuferFileB.st_nlink);
 printf("******************************************************\n");    
 getchar();
 system("clear");
 // Open clone 'fileA' for read
 HandleFileAClone=open("fileA",O_RDONLY); 
 if(HandleFileAClone < 0) { printf("\nError!"); return 1; }
 printf("----- Open fileA clone for read ------\n");
 printf("************** Table file ****************************\n");
 printf("** Filename ********** Record in table openfiles *****\n");
 printf("1. STDIN        *      -                              \n");
 printf("2. STDOUT       *      -                              \n");
 printf("3. STDERR       *      -                              \n");
 printf("4. fileA        *      1, 3                           \n");
 printf("5. fileB        *      2                              \n");
 printf("******************************************************\n");
 printf("\n");
 printf("************** Table open files **********************\n");
 printf("** Filename *** Position *** Record in table stat ****\n");
 printf("1. fileA     *  0 (read)  *  1                        \n");
 printf("2. fileB     *  0 (write) *  2                        \n");    
 printf("3. fileA     *  0 (read)  *  1                        \n");
 printf("******************************************************\n");    
 printf("\n");
 printf("************** Table stat files **********************\n");
 printf("** Filename *** Inode *** Mode *** Size *** Link *****\n");    
 printf("1. fileA     *  %5d  * %5d  *  %5d  * %5d  \n",
        BuferFileA.st_ino,
	BuferFileA.st_mode,
	BuferFileA.st_size,
        BuferFileA.st_nlink);
 printf("2. fileB     *  %5d  * %5d  *  %5d  * %5d  \n",
	BuferFileB.st_ino,
	BuferFileB.st_mode,
	BuferFileB.st_size,
	BuferFileB.st_nlink);
 printf("******************************************************\n");    
 getchar();
 system("clear");

 // Read of 'fileA' 10 symbols of HandleFileA
 count=read(HandleFileA,RecvMessage,10);
 if(count < 10) { printf("\nError!"); return 1; }
 printf("----- Read of fileA 10 symbols -----\n"); 
 printf("************** Table file ****************************\n");
 printf("** Filename ********** Record in table openfiles *****\n");
 printf("1. STDIN        *      -                              \n");
 printf("2. STDOUT       *      -                              \n");
 printf("3. STDERR       *      -                              \n");
 printf("4. fileA        *      1, 3                           \n");
 printf("5. fileB        *      2                              \n");
 printf("******************************************************\n");
 printf("\n");
 printf("************** Table open files **********************\n");
 printf("** Filename *** Position *** Record in table stat ****\n");
 printf("1. fileA     *  10 (read) *  1                        \n");
 printf("2. fileB     *  0 (write) *  2                        \n");    
 printf("3. fileA     *  0 (read)  *  1                        \n");
 printf("******************************************************\n");    
 printf("\n");
 printf("************** Table stat files **********************\n");
 printf("** Filename *** Inode *** Mode *** Size *** Link *****\n");    
 printf("1. fileA     *  %5d  * %5d  *  %5d  * %5d  \n",
        BuferFileA.st_ino,
	BuferFileA.st_mode,
	BuferFileA.st_size,
        BuferFileA.st_nlink);
 printf("2. fileB     *  %5d  * %5d  *  %5d  * %5d  \n",
	BuferFileB.st_ino,
	BuferFileB.st_mode,
	BuferFileB.st_size,
	BuferFileB.st_nlink);
 printf("******************************************************\n");    
 getchar();
 system("clear");

 // Read of 'fileA' 5 symbols of clone handle
 count=read(HandleFileAClone,RecvMessage,5);
 if(count < 5) { printf("\nError!"); return 1; }
 printf("----- Read 5 symbols of fileA clone -----\n");
 printf("************** Table file ****************************\n");
 printf("** Filename ********** Record in table openfiles *****\n");
 printf("1. STDIN        *      -                              \n");
 printf("2. STDOUT       *      -                              \n");
 printf("3. STDERR       *      -                              \n");
 printf("4. fileA        *      1, 3                           \n");
 printf("5. fileB        *      2                              \n");
 printf("******************************************************\n");
 printf("\n");
 printf("************** Table open files **********************\n");
 printf("** Filename *** Position *** Record in table stat ****\n");
 printf("1. fileA     *  10 (read) *  1                        \n");
 printf("2. fileB     *  0 (write) *  2                        \n");    
 printf("3. fileA     *  5 (read)  *  1                        \n");
 printf("******************************************************\n");    
 printf("\n");
 printf("************** Table stat files **********************\n");
 printf("** Filename *** Inode *** Mode *** Size *** Link *****\n");    
 printf("1. fileA     *  %5d  * %5d  *  %5d  * %5d  \n",
        BuferFileA.st_ino,
	BuferFileA.st_mode,
	BuferFileA.st_size,
        BuferFileA.st_nlink);
 printf("2. fileB     *  %5d  * %5d  *  %5d  * %5d  \n",
	BuferFileB.st_ino,
	BuferFileB.st_mode,
	BuferFileB.st_size,
	BuferFileB.st_nlink);
 printf("******************************************************\n");    
 getchar();
 system("clear");
 // Write of 'fileB' 7 symbols 
 count=write(HandleFileB,Message,7);
 if(count < 7) { printf("\nError!"); return 1; }
 printf("----- Write 7 symbols in fileB -----\n");
 printf("************** Table file ****************************\n");
 printf("** Filename ********** Record in table openfiles *****\n");
 printf("1. STDIN        *      -                              \n");
 printf("2. STDOUT       *      -                              \n");
 printf("3. STDERR       *      -                              \n");
 printf("4. fileA        *      1, 3                           \n");
 printf("5. fileB        *      2                              \n");
 printf("******************************************************\n");
 printf("\n");
 printf("************** Table open files **********************\n");
 printf("** Filename *** Position *** Record in table stat ****\n");
 printf("1. fileA     *  10 (read) *  1                        \n");
 printf("2. fileB     *  7 (write) *  2                        \n");    
 printf("3. fileA     *  5 (read)  *  1                        \n");
 printf("******************************************************\n");    
 printf("\n");
 printf("************** Table stat files **********************\n");
 printf("** Filename *** Inode *** Mode *** Size *** Link *****\n");    
 printf("1. fileA     *  %5d  * %5d  *  %5d  * %5d  \n",
        BuferFileA.st_ino,
	BuferFileA.st_mode,
	BuferFileA.st_size,
        BuferFileA.st_nlink);
 printf("2. fileB     *  %5d  * %5d  *  %5d  * %5d  \n",
	BuferFileB.st_ino,
	BuferFileB.st_mode,
	BuferFileB.st_size,
	BuferFileB.st_nlink);
 printf("******************************************************\n");    
 getchar();
 system("clear");
 // Close all user handle
 close(HandleFileA);
 close(HandleFileB);
 close(HandleFileAClone);
 printf("----- Close user files -----\n");
 printf("************** Table file ****************************\n");
 printf("** Filename ********** Record in table openfiles *****\n");
 printf("1. STDIN        *      -                              \n");
 printf("2. STDOUT       *      -                              \n");
 printf("3. STDERR       *      -                              \n");
 printf("******************************************************\n");
 printf("\n");
 printf("************** Table open files **********************\n");
 printf("** Filename *** Position *** Record in table stat ****\n");
 printf("******************************************************\n");    
 printf("\n");
 printf("************** Table stat files **********************\n");
 printf("** Filename *** Inode *** Mode *** Size *** Link *****\n");    
 printf("******************************************************\n");    
 getchar();
 system("clear");
 return 0;
}

