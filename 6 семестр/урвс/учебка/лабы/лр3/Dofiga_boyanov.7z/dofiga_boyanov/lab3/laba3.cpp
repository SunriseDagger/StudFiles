#include <iostream>
#include <sys/stat.h>
#include <sys/types.h>
#include <cstdlib>

using namespace std;

struct TableLine
{
    char filename[128];
    char filedescr[128];
};


class Process
{
    //number of opened files
    int Count;
    //number of main process which forked this process
    int MainNumber;
    //max number of element
    int max;
 public:     
    TableLine  *tableptr;
    Process(int x)
    {
	max  =x;
	tableptr = new TableLine [x];
    }
    ~Process()
    {
	delete [] tableptr;
    }
    void setCount(int y){ Count = y;}
    void addCount(int num){ Count += num;}
    int getCount(){ return Count;}
    void setMainNumber(int x){MainNumber = x;}
};

void setTableList(int num,char  filename[128], char filedescriptor[128])
{
 char temp[128];
    strcpy(filename,"file");
    sprintf(temp,"%d",num);
    strcat(filename,temp);
    strcpy(filedescriptor,"fd");
    sprintf(temp,"%d",num);
    strcat(filedescriptor,temp);

}

void setStandartFiles(Process **Pr,int N)
{
    for(int i=0; i<N; i++)
    {
	strcpy(Pr[i]->tableptr[0].filename,"stdin");
	strcpy(Pr[i]->tableptr[0].filedescr,"0");
    
        strcpy(Pr[i]->tableptr[1].filename,"stdout");
	strcpy(Pr[i]->tableptr[1].filedescr,"1");
    
        strcpy(Pr[i]->tableptr[2].filename,"stderr");
	strcpy(Pr[i]->tableptr[2].filedescr,"2");
    }	
}

void printList(Process *Pr)
{
    for(int i=0;i<Pr->getCount()+3; i++)
    {
	 cout<<Pr->tableptr[i].filename<<"\t\t"<<Pr->tableptr[i].filedescr<<endl;
    }
}

int main(int argc, char **argv)
{
    if(argc==4)
    {
     int nfile = 0, number, tempCount, addfiles ;
     int N = atoi(argv[1]);//number of main processes
     int M = atoi(argv[2]);//number of daugter processes
     int K = atoi(argv[3]);//number of files for daughter processes
     Process* Main[256];
    // define another initial value for rand()
     srand(N+K+M);
     for(int i=0; i<N; i++)
        Main[i]= new Process(N+3);
     Process* Daughter[256];
     for(int i=0; i<M; i++)
        Daughter[i] = new Process(N+K+3);	            
     //MainProcesses
      setStandartFiles(Main,N); 
        for(int i=0; i<N; i++)
        {
	    cout<<"Table of opened files for process_"<<i<<endl;
	    cout<<"file \t\t"<<"file"<<endl;
	    cout<<"name\t\t"<<"descriptor"<<endl;
	    //How much files will opened 
	    number = rand()%N;
	    Main[i]->setCount(number);
	    tempCount = number+3;
	    for(int j=3; j<tempCount; j++)
	    {
		//number of file to open
		nfile = rand()%N;
		setTableList(nfile,Main[i]->tableptr[j].filename,Main[i]->tableptr[j].filedescr);
	    }
	    printList(Main[i]);
        }	    
     //New daughter process
	 for(int i=0;i<M; i++)
        {
    	    //number of mainprocess to fork a daughter process
	    number = rand()%N;
	    Daughter[i]->setMainNumber(number);
	    cout<<"Process number_"<<number<<" forked a daughter process_"<<N+i<<endl;
	    cout<<"Table of opened files for process_"<<N+i<<endl;
	    cout<<"file\t\t"<<"file"<<endl;
	    cout<<"name\t\t"<<"descriptor"<<endl;
	    //copy main table to daughter table
	    Daughter[i]->setCount(Main[number]->getCount());
	    tempCount = Daughter[i]->getCount()+3;
	    for(int j=0; j<tempCount; j++)
	    {
		strcpy(Daughter[i]->tableptr[j].filename , Main[number]->tableptr[j].filename);
		strcpy(Daughter[i]->tableptr[j].filedescr , Main[number]->tableptr[j].filedescr);
	    }
	    printList(Daughter[i]);
        }
     //DaughterProcesses
        for(int i=0; i<K; i++)
        {
	    //what process will open files?
	    number = rand()%M;
	    //How much files open in addittion
	    addfiles  = rand()%K;
	    tempCount = addfiles+Daughter[number]->getCount()+3;
	    for(int j=Daughter[number]->getCount()+3; j<tempCount; j++)
	    {
		//what file will be opened?
		nfile = rand()%N;
		setTableList(nfile,Daughter[number]->tableptr[j].filename,Daughter[number]->tableptr[j].filedescr); 
	    }
	    cout<<"Process number_"<<N+number<<" opened in addittion "<<addfiles<<" files"<<endl;
	    cout<<"file\t\t"<<"file"<<endl;
	    cout<<"name\t\t"<<"descriptor"<<endl;
	    Daughter[number]->addCount(addfiles);
	    printList(Daughter[number]);
        }		
     for(int i=0; i<N; i++)
        delete Main[i];     
     for(int i=0; i<M; i++)
        delete Daughter[i]; 
    }
}
