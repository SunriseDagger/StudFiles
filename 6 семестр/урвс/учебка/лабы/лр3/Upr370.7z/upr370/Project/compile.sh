#!/bin/sh
g++ -o upr37 sources/main.cpp
