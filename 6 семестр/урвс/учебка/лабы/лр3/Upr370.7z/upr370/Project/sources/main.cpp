/**
@detailed This programme able to simulate changes 
related with daughter of processes by fork()
@author Kurochkin A.V.
@author Popkov I.V.
@version 0.1
*/
#include <iostream>
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>
#include <stdio.h>
#include <cstdlib>
/**
@brief Main function
@param argc number of arguments
@param argv arguments
@return 0 - successfull run, 1 - incorrect work
*/
int main(int argc, char **argv)
{
    int i;
    if(argc == 6)
    {
        int nparent = atoi(argv[1]);/** nparent - number of parent processes */
        int fparent = atoi(argv[2]);/** fparent - number of files had been opened by parent processes */
        int nchild = atoi(argv[3]);/** nchild - number of childs*/
        int nopnchild = atoi(argv[3]);/** nopnchild - number of able to open childs */
        int fchild = atoi(argv[5]);/** fchild - number of files opened by childs */
        for(i = 0; i < nparent; i++)
        {
            printf("Table of opened files of process_%d\n",i);
            printf("file\t\t\t\t\tfile\n");
            printf("name\t\t\t\t\tdescriptor\n");
            printf("stdin\t\t\t\t\t0\n");
            printf("stdout\t\t\t\t\t1\n");
            printf("stderr\t\t\t\t\t2\n");
            for(int j = 0; j < fparent; j++)
            {
                printf("file%d\t\t\t\t\tfd%d\n",j,j);
            }
        }
        if(nchild <= nparent)
        {
            for(i = 0; i < nchild; i++)
            {
                printf("process_%d become a child process of process_%d\n",i+nparent,i);
                if(i < nopnchild)
                {
                    printf("process_%d opened %d files\n",i+nparent,fchild);
                    printf("Table of opened files of process_%d\n",i+nparent);
                    printf("file\t\t\t\t\tfile\n");
                    printf("name\t\t\t\t\tdescriptor\n");
                    printf("stdin\t\t\t\t\t0\n");
                    printf("stdout\t\t\t\t\t1\n");
                    printf("stderr\t\t\t\t\t2\n");
                    for(int j = 0; j < fchild+fparent; j++)
                    {
                        printf("file%d\t\t\t\t\tfd%d\n",j,j);
                    }
                }
            }
        }
        else
            return 1;
        return 0;
    }
    else
        return 1;
}
