./upr37 3 2 2 1 2 > cmps/res1
./upr37 1 1 0 0 0 > cmps/res2
./upr37 2 2 1 1 1 > cmps/res3
./upr37 100 85 93 56 45 > cmps/res4
{
cmp cmps/res1s cmps/res1 &&
cmp cmps/res2s cmps/res2 &&
cmp cmps/res3s cmps/res3 &&
cmp cmps/res4s cmps/res4 &&
echo "All the tests had been passed successfully!"
} || echo "A test had been failed!"

