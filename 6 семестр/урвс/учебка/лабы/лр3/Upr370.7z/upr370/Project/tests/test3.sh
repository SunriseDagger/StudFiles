../upr37 2 2 1 1 1 > ../cmps/res3
