#!/bin/sh

doxygen upr370.cfg
