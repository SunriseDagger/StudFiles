../upr37 100 85 93 56 45 > ../cmps/res4
