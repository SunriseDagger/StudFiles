../upr37 3 2 2 1 2 > ../cmps/res1
