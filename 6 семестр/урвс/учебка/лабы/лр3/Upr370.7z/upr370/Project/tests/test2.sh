../upr37 1 1 0 0 0 > ../cmps/res2
