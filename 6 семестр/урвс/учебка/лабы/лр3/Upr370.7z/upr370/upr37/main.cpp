#include <iostream>
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>
#include <stdio.h>
#include <cstdlib>
int main(int argc, char **argv)
{
    int i;
    if(argc == 6)
    {
        int nparent = atoi(argv[1]);
        int fparent = atoi(argv[2]);
        int nchild = atoi(argv[3]);
        int nopnchild = atoi(argv[3]);
        int fchild = atoi(argv[5]);
        for(i = 0; i < nparent; i++)
        {
            printf("Table of opened files of process_%d\n",i);
            printf("file\t\t\t\t\tfile\n");
            printf("name\t\t\t\t\tdescriptor\n");
            printf("stdin\t\t\t\t\t0\n");
            printf("stdout\t\t\t\t\t1\n");
            printf("stderr\t\t\t\t\t2\n");
            for(int j = 0; j < fparent; j++)
            {
                printf("file%d\t\t\t\t\tfd%d\n",j,j);
            }
        }
        if(nchild <= nparent)
        {
            for(i = 0; i < nchild; i++)
            {
                printf("process_%d become a child process of process_%d\n",i+nparent,i);
                if(i < nopnchild)
                {
                    printf("process_%d opened %d files\n",i+nparent,fchild);
                    printf("Table of opened files of process_%d\n",i+nparent);
                    printf("file\t\t\t\t\tfile\n");
                    printf("name\t\t\t\t\tdescriptor\n");
                    printf("stdin\t\t\t\t\t0\n");
                    printf("stdout\t\t\t\t\t1\n");
                    printf("stderr\t\t\t\t\t2\n");
                    for(int j = 0; j < fchild+fparent; j++)
                    {
                        printf("file%d\t\t\t\t\tfd%d\n",j,j);
                    }
                }
            }
        }
        else
            return 1;
        return 0;
    }
    else
        return 1;
}
