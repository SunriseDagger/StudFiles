tests/client > tests/r2
echo 1
tests/client > tests/r3
echo 2
sleep 10
tests/clients > tests/r4
echo 3
{
cmp tests/cmps/srv tests/r1 && 
echo "Test 1 successfully passed"
} || echo "Test 1 failed!"
{
cmp tests/cmps/c1 tests/r2 && 
echo "Test 2 successfully passed"
} || echo "Test 2 failed!"
{
cmp tests/cmps/c2 tests/r3 && 
echo "Test 3 successfully passed"
} || echo "Test 3 failed!"
{
cmp tests/cmps/c3 tests/r4 && 
echo "Test 4 successfully passed"
} || echo "Test 4 failed!"

sleep 5

