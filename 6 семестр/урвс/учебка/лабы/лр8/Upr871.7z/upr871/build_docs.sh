#!/bin/sh

doxygen upr870.cfg
