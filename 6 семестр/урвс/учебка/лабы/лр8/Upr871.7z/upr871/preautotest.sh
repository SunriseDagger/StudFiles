tests/server > tests/r1
