/**
 * @file server.cpp
 * @detailed The programme is a server, 
 * which allow clients to try insert the password 3 times, then block them
 * @author Kurochkin A.V.
 * @version 1.3
 */
#include <stdio.h>
#include <iostream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <set>
#include <vector>
using namespace std;
struct bans_l8 //<! Элемент структуры, хранящей IP-адрес и время блокировки
{
    int banip; //<! IP-адрес
    long bantime; //<! Время блокировки
};
//<! Операторы сравнения для объектов типа bans_l8, необходимо для пременения set
bool operator > (const bans_l8 &b1, const bans_l8 &b2)
{
    return 0;
}
bool operator < (const bans_l8 &b1, const bans_l8 &b2)
{
    return 0;
}
bool operator == (const bans_l8 &b1, const bans_l8 &b2)
{
    return 0;
}
main()
{
    set<bans_l8> bnip; //<! Множество, хранящее записи о блокировке
    set<bans_l8>::iterator itb; //<! Итератор, необходимый для оперирования со множеством
    bans_l8 blocknow; //<! Экземпляр структуры
    struct timeval tv; //<! Переменная для хранения времени
    struct timezone tz; //<! Переменная для хранения зоны
    int sockfd, newsockfd, n; //<! Дескрипторы
    int bstime; //<! Время блокировки
    int flag = 0, banrcon = 0; //<! Флаги, отвечающие за передачу информации о том, 
                               //<! пытаются ли совершить подключение заблокированные
    char buffer[256];
    socklen_t cli_len;
    sockaddr_in serv_addr, cli_addr;
    cout << "LAB 8 SERVER" << endl;
    sockfd = socket(AF_INET, SOCK_STREAM, 0); //<! Инициализация сокета
    if (sockfd < 0) //<! Обработка ошибки
	{
        cout << "Server:[ERROR] Socket had been not created!" << endl;
        close(sockfd);
        close(newsockfd);
        return 1;
    }
    else cout << "Server: Obtained sockfd: " << sockfd << endl;
    bzero((char *) &serv_addr, sizeof(serv_addr)); //<! Очистка адреса
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY; //<! Любой адрес
    FILE *F = fopen("config","r");
    int tmod;
    int s_port;
    fscanf(F, "%d", &s_port);
    fscanf(F, "%d", &tmod);
    fscanf(F, "%d", &bstime);
    fclose(F);
    cout << "Server: Works on port: " << s_port << endl;
    serv_addr.sin_port = htons(s_port); //<! Установка порта
    if(bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0)
    {//<! Бинд сокета или обработка возможной ошибки
        cout << "Server:[ERROR] Socket had been not binded!" << endl;
        close(sockfd);
        close(newsockfd);
        return 1;
    }
    listen(sockfd,5);//<! Слушаем сокет
    while(!flag)//<! Оканчиваем работу только если пароль введён правильно
    {
        cli_len = sizeof(cli_addr);//<! Подготовка к соединению
        newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &cli_len);
        for(int j = 0; j < bnip.size(); j++)
        {
            banrcon = 0;//<! Сброс флага попытки соединения заблокированного
            itb = bnip.begin();//<! Итератор на "начало" множества
            gettimeofday(&tv,&tz);//<! Получаем текущее время
            if((*itb).banip == cli_addr.sin_addr.s_addr && (bstime - (tv.tv_sec - (*itb).bantime)) >= 0)
            {//<! Если клиент в списке заблокированных и время блокировки не вышло
                long btime = (*itb).bantime;
                long htime = tv.tv_sec;
                if(!tmod)
                cout << "Server: A blocked client tried to connect, but "<< (bstime - (tv.tv_sec - (*itb).bantime)) << "s block-time"<< endl;
                close(newsockfd);
                banrcon = 1;//<! Заблокированный пытался подключиться
                break;
            }
            itb++;//<! Сдвигаем итератор для проверки следующего элемента множества
        }
        if(!banrcon)//<! Если поытка соединения незаблокированного клиента
        {
            if(newsockfd < 0)//<! Обработка ошибок
            {
                cout << "Server: Error in socket accepting" << endl;
                close(sockfd);
                close(newsockfd);
                return 1;
            }
            int i = 0;
            flag = 0;
            for(i = 0; i < 3; i++)
            {//<! Начинаем проверку пароля, есть 3 попытки
                bzero(buffer,256);//<! Очистка буфера
                n = read(newsockfd,buffer,255);//<! Прочтём пароль
                if(n < 0)//<! Обработка ошибок
                {
                    cout << "Server: Error reading from socket" << endl;
                }
                cout << "Server: Password recieved: " << buffer << endl;//<! Вывод пароля
                if(strcmp (buffer,"password") == 0)//<! Проверка пароля
                {
                    i = 5;//<! Выход из цикла
                    n = write(newsockfd,"Correct",7);//<! Сообщаем о корректности пароля
	                flag = 1;//<! Выход из внешнего цикла при правильном пароле, если поставить 1, при 0 - бесконечная программа
                    if(n < 0) cout << ("Server: Error of writing in socket");//<! Обработка ошибки
                }
                else
                {//<! Если пароль некорректен
                    n = write(newsockfd,"Server: Password is incorrect",29);//<! Сообщаем клиенту
                    if(n < 0)//<! Обработка ошибки
                    {
                        cout << "Server: Error of writing in socket"  << endl;
                    }
                }  
                if(i == 2)
                {//<! Секция блокировки
                    blocknow.banip = cli_addr.sin_addr.s_addr;//<! IP-адрес
                    gettimeofday(&tv,&tz);//<! Время
                    blocknow.bantime = tv.tv_sec;
                    itb = bnip.find(blocknow);//<! Поиск, не дублируем ли
                    if(itb != bnip.end())
                        bnip.erase(itb);//<! Стираем дубль
                    bnip.insert(blocknow);//<! Добавляем новую запись
                    cout << "Server: Blocking insertion for " << bstime << " s" << endl;
                    n = write(newsockfd,"\nServer: You are blocked for some time",43);//<! Сообщение клиенту
                    sleep(1);
                    close(newsockfd);
                    break;
                    if(n < 0) cout << ("Server: Error of writing in socket");//<! Обработка ошибки
                }
                if(flag)
                {
                    close(sockfd);
                    close(newsockfd);
                    return 0;
                }
            }
        }
    }
    close(sockfd);
    close(newsockfd);
    return 0;   
}
