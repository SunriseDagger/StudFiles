/**
 * @file client.cpp
 * @detailed The programme is a client, 
 * which connect to the server to insert a password
 * @author Kurochkin A.V.
 * @version 1.3
 */
#include <stdlib.h>
#include <stdio.h>
#include <iostream>
#include <sys/socket.h>
#include <netinet/in.h>
#include <errno.h>
#include <string.h>
#include <netdb.h> 
using namespace std;
main()
{
    cout << "LAB 8 CLIENT" << endl;
    int sockfd, n;
    int flag = 0;
    sockaddr_in serv_addr;
    hostent *server;
    char buffer[256];
    FILE *F = fopen("config","r");
    int s_port;
    fscanf(F, "%d", &s_port);
    fclose(F);
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if(sockfd < 0)
    {
        cout << "Client: Error in socket creating" << endl;
        close(sockfd);
        return (1);
    }
    else cout << "Client: Aquired sockfd = " << sockfd << endl;
    server = gethostbyname("localhost");
    if(server == NULL)
    {
        cout << "Client: Error, no such host"<<endl;
        close(sockfd);
        return 1;
    }
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    bcopy((char *)server->h_addr, (char *)&serv_addr.sin_addr.s_addr, server->h_length);
    serv_addr.sin_port = htons(s_port);
    if(connect(sockfd,(struct sockaddr *) &serv_addr,sizeof(serv_addr)) < 0)
    {
        cout<< "Client: Error in connecting"<<endl;
        close(sockfd);
        return 1;
    }
    int num = 0;
    while(strcmp (buffer,"Correct") != 0 || flag)
    {
        cout << "Client: Enter password:" << endl;
        bzero(buffer,256);
	sleep(1);
	if(num == 0) strcpy(buffer,"trkey1");
	if(num == 1) strcpy(buffer,"trkey2");
	if(num == 2) strcpy(buffer,"password");
	if(num == 3) strcpy(buffer,"trkey4");
	num++;
        //cin >> buffer;	
        n = write(sockfd,buffer,strlen(buffer));
        if(n < 0)
        {
            cout << "Client: Error writing to socket" << endl;
        }
        bzero(buffer,256);
        n = read(sockfd,buffer,255);
        if(n < 0)
        {
            cout<< "Client: Error reading from socket"<<endl;
        }
        cout << buffer << endl;
        if(strcmp(buffer,"Server: Password is incorrect") != 0 && strcmp (buffer,"Correct") != 0)
        {
            flag = 1;
            close(sockfd);
            return 0;
        }
    }
    close(sockfd);
    return 0;
}

