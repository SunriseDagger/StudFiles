#!/bin/sh
g++ -o server sources/server.cpp
g++ -o client sources/client.cpp
