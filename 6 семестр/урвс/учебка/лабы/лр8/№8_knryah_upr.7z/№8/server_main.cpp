#include <fstream>
#include <iostream>
#include <string>
#include <map>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <stdlib.h>
using namespace std;

/*Таблица ip-адресов dns-сервера*/
typedef map<string,string> ip_table;

/*Типы сообщений*/
enum type_msg{DATA,ERROR};

/*Структура сообщения*/
struct data
{
    type_msg type;
    char str[30];
};

/*Формирование таблицы ip-адресов
*
*file_1 - файл для чтения ip-таблицы
*tab - таблица ip-адресов
*/
int get_table(string &file_1,ip_table &tab)
{
    ifstream file(file_1.c_str());
    string name,ip;

    if(file==NULL)  //если нет файла
    {
        cout << "SERVER: Cannot open ip_file" << endl;
        return 1;
    }
    else
    {
        while(!file.eof())  //пока не конец файла
        {
            file >> name >> ip;
		cout << name << "\t"<< ip << endl;
            tab[name]=ip;
        }
	cout << "SERVER: IP table created ololo" << endl;
        return 0;
    }
}


/*Функция связывания сокета с ip-адресом и портом
*
*sockfd - дескриптор сокета
*port - порт сервера
*/
int bind_function(int sockfd,u_short port)
{
    sockaddr_in soc;        //структура с информацией о сервере
    soc.sin_family=AF_INET;
    soc.sin_addr.s_addr=INADDR_ANY;
    soc.sin_port=htons(port);

    int check=bind(sockfd,(sockaddr *)&soc,sizeof(soc));
    if(check<0) {close(sockfd); return 1;}
    else    return 0;
}


/*Функция получения ip-адреса сервера
*
*file - исходный файл
*ip - получаемый ip-адрес
*port - порт сервера
*/
int get_ip(ifstream &file,in_addr_t &ip,u_short &port)
{
    if (file==NULL) return -1;  //если нет файла
    string ip_str;
    file >> ip_str >> port;
    if (file.eof()) return -1;  //если конец файла
    in_addr ip_addr;
    inet_aton(ip_str.c_str(),&ip_addr); //функция перевода ip-адреса
                                        //в нужный тип
    ip = ip_addr.s_addr;
    return 0;
}

/*Функция установления соединения с сервером
*
*sockfd - дескриптор сокета
*ip - ip-адрес сервера
*port - порт сервера
*/
int connect_socket(int sockfd,in_addr_t ip_addr,u_short port)
{
    sockaddr_in s_addr;     //структура с информацией о сервере
    s_addr.sin_family=AF_INET;
    s_addr.sin_port=htons(port);
    s_addr.sin_addr.s_addr=ip_addr;
    int check=connect(sockfd,(sockaddr *)&s_addr,sizeof(s_addr));
    return check;
}
/*Функция обращения к следующему dns-серверу
*
*dns_file - файл с информацией о сервере
*ip - ip-адрес сервера
*port - порт сервера
*/
int another_dns(const string &dns_file,const string &srv_name,string &srv_ip)
{
    ifstream from(dns_file.c_str());
    in_addr_t dns_ip;
    u_short dns_port;

    while(get_ip(from,dns_ip,dns_port)==0)  //получаем ip-адрес сервера
    {
        int sockfd=socket(PF_INET,SOCK_STREAM,0);   //получаем дескриптор сокета сервера
        if(sockfd==-1) continue;

        if(connect_socket(sockfd,dns_ip,dns_port)<0)   continue;    //соединяемся с сервером

        data Msg;
        strcpy(Msg.str,srv_name.data());    //формируем сообщение
        write(sockfd,&Msg,sizeof(Msg));     //отправляем сообщение серверу

        read(sockfd,&Msg,sizeof(Msg));      //получаем сообщение сервера

        if(Msg.type==DATA)
        {
            srv_ip = Msg.str;
            return 0;
        }
        close(sockfd);
    }
    return -1;
}


int main(int argc,char *argv[])
{
    string dns_file,ip_file;
    u_short port;

    ip_table Table;
    data Msg;

    if(argc==4)
    {
        dns_file=argv[1];
        ip_file=argv[2];
        port=atoi(argv[3]);
        if(port==0)
        {
            cout << "SERVER: Incorrect data: port" << endl;
        }
    }
    else
    {
        cout << "SERVER: Incorrect data, use standart files" << endl;
        dns_file="dns.url";
        ip_file="ip.url";
        port=2000;
    }
    if(get_table(ip_file,Table)==1) //получение таблицы ip-адресов
    {
        cout << "SERVER: Error in get_table" << endl;
        return 1;
    }
    int sockfd = socket(PF_INET,SOCK_STREAM,0);   //получение дескриптора сокета сервера
    if(sockfd==-1)
    {
        cout << "SERVER: Cannot create socket" << endl;
        return 1;
    }
	cout << "SERVER: socket created" << endl;
    /*Позволяем повторное использование сокета*/
    int flag=1;
    int check=setsockopt(sockfd,SOL_SOCKET,SO_REUSEADDR,&flag,sizeof(flag));
    if(check < 0)
    {
        cout << "SERVER: Error in function setsockopt" << endl;
        return 1;
    }

    if(bind_function(sockfd,port)==1)   //связываем сокет с ip-адресом и портом
    {
        cout << "SERVER: Error in bind" << endl;
	close(sockfd);
        return 1;
    }
	cout << "SERVER: bind was succesful" << endl; 	
    listen(sockfd,1);   //открываем доступ для клиента

    int cl_sockfd=accept(sockfd,NULL,NULL); //ждем подключение клиента,
                                            //устанавливаем соединение

    read(cl_sockfd,&Msg, sizeof(Msg));  //получаем сообщение клиента

    string srv_name=Msg.str;
    string srv_ip;
    //ищем заданное имя
    if (Table.find(srv_name) != Table.end())  //если нашли заданное имя в таблице
    {
            Msg.type=DATA;
            strcpy(Msg.str,Table[srv_name].c_str());
    }
    //ищем заданное имя на другом dns-сервере
    else if(another_dns(dns_file,srv_name,srv_ip)==0) //если нашли заданное имя
                                                      //на другом dns-сервере
    {
            Msg.type = DATA;
            strcpy(Msg.str, srv_ip.c_str());
    }
    else    //если не нашли
    {
            Msg.type = ERROR;
    }
    write(cl_sockfd,&Msg,sizeof(Msg));  //посылаем сообщение клиенту
    close(cl_sockfd);   //закрываем дескриптор на сокет клиента
    close(sockfd);      //закрываем дескриптор на сокет сервера

    return 0;
}
