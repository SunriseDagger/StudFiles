#include <fstream>
#include <iostream>
#include <string>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
using namespace std;

/*Типы сообщений*/
enum type_msg{DATA,ERROR};

/*Структура сообщения*/
struct data
{
    type_msg type;
    char str[30];
};


/*Функция получения ip-адреса сервера
*
*file - исходный файл
*ip - получаемый ip-адрес
*port - порт сервера
*/
int get_ip(ifstream &file,in_addr_t &ip,u_short &port)
{
    if (file==NULL) return -1;
    string ip_str;
    file >> ip_str >> port;
    if (file.eof()) return -1;
    in_addr ip_addr;
    inet_aton(ip_str.c_str(),&ip_addr);
    ip = ip_addr.s_addr;
    return 0;
}


/*Функция установления соединения с сервером
*
*sockfd - дескриптор сокета
*ip - ip-адрес сервера
*port - порт сервера
*/
int connect_socket(int sockfd,in_addr_t ip_addr,u_short port)
{
    sockaddr_in s_addr;
    s_addr.sin_family=AF_INET;
    s_addr.sin_port=htons(port);
    s_addr.sin_addr.s_addr=ip_addr;
    int check=connect(sockfd,(sockaddr *)&s_addr,sizeof(s_addr));
    return check;
}

int main(int argc, char *argv[])
{
    string srv_name;
    string dns_file;

    if(argc==3)
    {
        srv_name = argv[1];
        dns_file = argv[2];
    }
    else
    {
        cout << "Incorrect data" << endl;
        srv_name ="name.ru";
        dns_file ="dns.url";
    }

    ifstream from_dns(dns_file.c_str());
    in_addr_t dns_ip;
    u_short dns_port;

    if(get_ip(from_dns,dns_ip,dns_port)<0)  //получаем ip-адрес сервера
    {
        cout << "Can't get server IP" << endl;
        return 1;
    }

    int sockfd=socket(PF_INET,SOCK_STREAM, 0);  //получаем дескриптор сокета сервера
    if(sockfd==-1)
    {
        cout << "Can't open socket" << endl;
        return 1;
    }
    int check=connect_socket(sockfd,dns_ip,dns_port);   //соединяемся с сервером
    if(check<0)
    {
        cout << "Can't connect with dns server" << endl;
        return 1;
    }

    data Msg;
    strcpy(Msg.str,srv_name.data());    //формируем сообщение
    write(sockfd,&Msg,sizeof(Msg));     //отправляем сообщение серверу

    read(sockfd,&Msg,sizeof(Msg));      //получаем сообщение сервера

    if (Msg.type==DATA)
    {
        cout << "Server " << srv_name << " has ip " << Msg.str << endl;
    }
    else
    {
        cout << "Unknown server name " << srv_name << endl;
    }

    close(sockfd);  //закрываем дескриптор на сокет сервера
    return 0;
}

