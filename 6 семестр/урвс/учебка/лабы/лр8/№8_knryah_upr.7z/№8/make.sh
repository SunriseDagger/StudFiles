g++ -wall -o server server_main.cpp
g++ -wall -o client client_main.c

