#!/bin/sh

doxygen upr470.cfg
