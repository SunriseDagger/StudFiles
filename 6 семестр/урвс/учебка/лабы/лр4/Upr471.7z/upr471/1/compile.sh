#!/bin/sh
g++ -o upr470 sources/main.cpp
