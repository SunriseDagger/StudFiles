#!/bin/sh
g++ -o upr470 sources/main.cpp
g++ -o process sources/process.cpp
