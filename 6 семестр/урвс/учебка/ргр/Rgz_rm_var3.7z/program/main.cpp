#include <windows.h>
#include <shlwapi.h> // for wnsprintf
#include "../library/library.h" // include header from nearlying project
#pragma comment(lib, "library.lib") // this is copied through build
#pragma comment(lib, "shlwapi.lib") // for wnsprintf

#define BUFSIZE 64
volatile int a = -1; // volatile identifier is for thread-safety
int l = -1; // this is not volatile due to passing by reference
char buf[BUFSIZE];

DWORD WINAPI ThreadFunc(void* lParam) {
	a = GetMetricLevel2(l);
	return 0;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
	PAINTSTRUCT ps;
	HDC dc;
	switch(uMsg) {
	case WM_PAINT:
		// wsprintf is unsafe!!
		dc = BeginPaint(hWnd, &ps);
		wnsprintf(buf, BUFSIZE - 1, "Count of monitors: %d", a);
		TextOut(dc, 110, 20, buf, lstrlen(buf));
		wnsprintf(buf, BUFSIZE - 1, "RDTSC support: %s", ((l == 1) ? "YES" : "NO"));
		TextOut(dc, 110, 40, buf, lstrlen(buf));
		EndPaint(hWnd, &ps);
		break;
	case WM_DESTROY:
		PostQuitMessage(EXIT_SUCCESS);
		break;
	default:
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}
	return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrev, LPSTR CmdLine, int nCmdShow) {
	HANDLE hThread;
	DWORD IDThread;
	hInstance = GetModuleHandle(NULL);
	WNDCLASS wcl;
	HWND hWnd;
	LPSTR szClassName = "SampleClass3";
	wcl.hInstance = hInstance;
	wcl.lpszClassName = szClassName;
	wcl.lpfnWndProc = WndProc;
	wcl.style = CS_VREDRAW | CS_HREDRAW;
	wcl.hIcon = NULL;
	wcl.hCursor = NULL;
	wcl.lpszMenuName = NULL;
	wcl.cbClsExtra = NULL;
	wcl.cbWndExtra = NULL;
	wcl.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);

	if(!RegisterClass(&wcl))
		return GetLastError();
	if(!(hWnd = CreateWindow(
		szClassName, "���������� ���������: ������ � WinAPI", 
		WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, 
		0, 0, 370, 120, HWND_DESKTOP, NULL, hInstance, NULL
		))) return GetLastError();
	// DONE: add thread here
	if(!(hThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ThreadFunc, NULL, NULL, &IDThread)))
		return GetLastError();
	WaitForSingleObject(hThread, INFINITE);
	CloseHandle(hThread);
	// process window object further
	ShowWindow(hWnd, SW_SHOWNORMAL); // nCmdShow is ignored w/o CRT
	UpdateWindow(hWnd); // return 4;

	// standard cycle of processing messages
	MSG msg;
	while(GetMessage(&msg, NULL, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	ExitProcess(msg.wParam); // exit process (not only main thread) with WM_DESTROY code
	return EXIT_SUCCESS; // for compiler only
}