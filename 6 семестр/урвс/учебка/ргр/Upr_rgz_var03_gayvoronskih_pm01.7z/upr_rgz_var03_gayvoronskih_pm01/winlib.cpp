#include <windows.h>
extern "C"
__declspec(dllexport)
int numb_monitors_back()
{
    return GetSystemMetrics(SM_CMONITORS);
}
extern "C"
__declspec(dllexport)
int search_rdtsc()
{
    int rdtsc;
    __asm
    {
        mov eax, 1          ; EAX=1: Processor Info and Feature Bits
        cpuid               ; call CPUID
        and edx, 10h   		; mask
        shr edx, 4          ; shift to 4 bit
        mov rdtsc, edx      ; save result
    }
    return rdtsc;
}