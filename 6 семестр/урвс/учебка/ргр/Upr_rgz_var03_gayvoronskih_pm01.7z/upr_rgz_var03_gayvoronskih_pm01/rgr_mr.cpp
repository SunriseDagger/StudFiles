#include <windows.h>
#include <string>
#include <sstream>
using namespace std;
HWND hwnd, label;
void thread(){
    HINSTANCE hinstLib = LoadLibrary(TEXT("winlib.dll"));
	stringstream lbl;
    if(hinstLib != NULL){
        typedef int (*numb_monitors_back_)();
        numb_monitors_back_ numb_monitors_back = (numb_monitors_back_)GetProcAddress(hinstLib, "numb_monitors_back");
        if(numb_monitors_back != NULL){
            lbl << "made by Gayvoronskih Anna from pm01 ;)" 
			<< endl << "\t\t3d lvl" << endl <<
            "Quantity of monitors is: " << numb_monitors_back() << endl << endl;
        }
        else{
            stringstream msg;
            msg << "int numb_monitors_back() not found in winlib.dll";
            MessageBox(hwnd, (msg.str()).c_str(), "Error", MB_OK | MB_ICONERROR);
        }
		
        typedef int (*search_rdtsc_)();
        search_rdtsc_ search_rdtsc = (search_rdtsc_)GetProcAddress(hinstLib, "search_rdtsc");
        if(search_rdtsc != NULL){
            int tsc = search_rdtsc();
            lbl << "\t\t4th lvl" << endl << "Support of RDTSC function: ";
            if(tsc > 0) lbl << "YES";
            else lbl << "NO";
            SetWindowText(label, (lbl.str()).c_str());
        }
        else{
            stringstream msg;
            msg << "int search_rdtsc() not found in winlib.dll";
            MessageBox(hwnd, (msg.str()).c_str(), "Error", MB_OK | MB_ICONERROR);
        }
        FreeLibrary(hinstLib);
    }
    else{
        stringstream msg;
        msg << "winlib.dll had been not found";
        MessageBox(hwnd, (msg.str()).c_str(), "Error", MB_OK | MB_ICONERROR);
    }
}
LONG WINAPI WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam){
    switch (Msg){
    case WM_CTLCOLORSTATIC:{
        DWORD CtrlID = GetDlgCtrlID((HWND)lParam);
        if (CtrlID == 1001){
            SetTextColor((HDC)wParam, RGB(255, 20, 147));
            SetBkColor((HDC)wParam, RGB(0, 0, 0));
            return (INT_PTR)GetStockObject(BLACK_BRUSH);
        }
    }
    break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, Msg, wParam, lParam);
    }
    return 0;
}
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    HFONT font_mono = (HFONT)GetStockObject(OEM_FIXED_FONT);
    WNDCLASS wnd;
    memset(&wnd, 0, sizeof(WNDCLASS));
    wnd.style = CS_HREDRAW | CS_VREDRAW;
    wnd.lpfnWndProc = WndProc;
    wnd.hInstance = hInstance;
    wnd.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    wnd.lpszClassName = "main_class";
    RegisterClass(&wnd);
    int window_width = 340;
    int window_height = 150;
    int border = 5;
    HDC hDCScreen = GetDC(NULL);
    hwnd = CreateWindow("main_class", "Gayvoronskih_rgz_var03", WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
        (GetDeviceCaps(hDCScreen, HORZRES) - window_width) / 2, (GetDeviceCaps(hDCScreen, VERTRES) - window_height) / 2,
        window_width, window_height, NULL, NULL, hInstance, NULL);
    RECT rt;
    GetClientRect(hwnd, &rt);
    window_width = rt.right;
    window_height = rt.bottom;
    label = CreateWindow("static", "", WS_CHILD | WS_VISIBLE | WS_BORDER,
        border, border, window_width - 2 * border, window_height - 2 * border,
        hwnd, (HMENU)1001, hInstance, NULL);
    SendDlgItemMessage(hwnd, 1001, WM_SETFONT, (WPARAM)GetStockObject(OEM_FIXED_FONT), TRUE);
    HANDLE hThread;
    DWORD IDThread;
    hThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)thread, NULL, 0, &IDThread);
    CloseHandle(hThread);
    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);
    MSG msg;
    while(GetMessage(&msg, NULL, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return 0;
}