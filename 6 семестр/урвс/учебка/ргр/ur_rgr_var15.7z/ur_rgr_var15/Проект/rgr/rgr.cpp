#include <windows.h>
#include <stdio.h>
#include <string>
#include <sstream>
#include <memory.h>
#include <tchar.h>

#include <locale> 
using namespace std;
HWND hwnd, labelUserN, labelAssoc;
 
DWORD WINAPI ThreadFunc(void *)
{ 

	HINSTANCE hinstLib = LoadLibrary(TEXT("info_lib.dll"));
	char a[40];

	  if(hinstLib != NULL)
	  {
        typedef void(*getName_)(char *);
        getName_ getName ;
		getName= (getName_)GetProcAddress(hinstLib, "getName");
			 
		
		typedef int (*get_l1_data_assoc_)(); 
		get_l1_data_assoc_ get_l1_data_assoc; 
		get_l1_data_assoc = (get_l1_data_assoc_)GetProcAddress(hinstLib, "get_l1_data_assoc");

	 if(getName != NULL)
        {   getName(a);

		  stringstream lbl;
			lbl << "������� 1: \n���������� ��� ������������:  "<<a << endl ;

            SetWindowText(labelUserN, (lbl.str()).c_str());
        }
        else
        {
           MessageBox(hwnd,"getName() �� �������" , "Error", MB_OK | MB_ICONERROR);
          
	 }



	 if(get_l1_data_assoc!=NULL)
	 {
		 int assoc =get_l1_data_assoc() ; 
		  stringstream lbl;
			lbl << "������� 2 :"<< endl<<"��������������� ���� ������ L1 =\t" << assoc ;
                     
            SetWindowText(labelAssoc, (lbl.str()).c_str());
		// printf("%d",assoc);
	 }else 
		 MessageBox(hwnd,"get_l1_data_assoc() not found" , "Error", MB_OK | MB_ICONERROR);

	  }
   FreeLibrary(hinstLib);


getchar() ;
return 0 ;
}


LONG WINAPI WndProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
    switch (Msg)
    {
    case WM_CTLCOLORSTATIC: /** Change color */
    {
        DWORD CtrlID = GetDlgCtrlID((HWND)lParam);
        if (CtrlID == 1001 || CtrlID == 1002)
        {
            SetTextColor((HDC)wParam, RGB(0, 0, 0));
            SetBkColor((HDC)wParam, RGB(255,255, 255));
            return (INT_PTR)GetStockObject(WHITE_BRUSH);
        }
    }
    break;
    case WM_COMMAND: /** Button clicked */
    {
        if (LOWORD(wParam) == 1003)
        {
            HANDLE hThread;
            DWORD IDThread;
            /** Launch in new thread */
            hThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ThreadFunc, NULL, 0, &IDThread);
            CloseHandle(hThread);
        }
        if (LOWORD(wParam) == 1004)
            PostQuitMessage(0);
    }
    break;
    case WM_DESTROY: /** Window closed */
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, Msg, wParam, lParam);
    }
    return 0;
}

/**
 * @brief Main function
 * @param hInstance handle to current instance of application
 * @param hPrevInstance handle to previous instance of application (always NULL)
 * @param lpCmdLine command line for application, excluding the program name
 * @param nCmdShow controls how window is to be shown
 * @return 0
 */
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	setlocale(LC_ALL,"Russian");
    /** Some fonts */
    HFONT font_std = (HFONT)GetStockObject(DEFAULT_GUI_FONT);
    HFONT font_mono = (HFONT)GetStockObject(ANSI_VAR_FONT);
    /** Some definition for main_class */
    WNDCLASS wnd;
    memset(&wnd, 0, sizeof(WNDCLASS));
    wnd.style = CS_HREDRAW | CS_VREDRAW;
    wnd.lpfnWndProc = WndProc;
    wnd.hInstance = hInstance;
    wnd.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    wnd.lpszClassName = "main_class";
    wnd.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(100));
    RegisterClass(&wnd);
    /** Some main window */
    int window_width = 300;
    int window_height = 200;
    int button_width = 75;
    int button_height = 25;
    int border = 5;
    HDC hDCScreen = GetDC(NULL);
    hwnd = CreateWindow("main_class", "��� ������� 15", WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX,
        (GetDeviceCaps(hDCScreen, HORZRES) - window_width) / 2, (GetDeviceCaps(hDCScreen, VERTRES) - window_height) / 2,
        window_width, window_height, NULL, NULL, hInstance, NULL);
    RECT rt;
    GetClientRect(hwnd, &rt);
    window_width = rt.right;
    window_height = rt.bottom;
  
    labelUserN = CreateWindow("static", "Click \"Run\"", WS_CHILD | WS_VISIBLE | WS_BORDER,
        border, border, window_width - 2 * border, (window_height - button_height - 4 * border) / 2,
        hwnd, (HMENU)1001, hInstance, NULL);
    SendDlgItemMessage(hwnd, 1001, WM_SETFONT, (WPARAM)font_mono, TRUE);
    labelAssoc = CreateWindow("static", "Click \"Run\"", WS_CHILD | WS_VISIBLE | WS_BORDER,
        border, (window_height - button_height) / 2, window_width - 2 * border, (window_height - button_height - 4 * border) / 2,
        hwnd, (HMENU)1002, hInstance, NULL);
    SendDlgItemMessage(hwnd, 1002, WM_SETFONT, (WPARAM)font_mono, TRUE);
    /** Running thread before show window */
    HANDLE hThread;
    DWORD IDThread;
    hThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ThreadFunc, NULL, 0, &IDThread);
    CloseHandle(hThread);
    /**  button: Exit */
	
    SendDlgItemMessage(hwnd, 1003, WM_SETFONT, (WPARAM)font_std, TRUE);

    CreateWindow("button", "�����", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
        window_width - border - button_width, window_height - border - button_height, button_width, button_height,
        hwnd, (HMENU)1004, hInstance, NULL);

    SendDlgItemMessage(hwnd, 1004, WM_SETFONT, (WPARAM)font_std, TRUE);
    /** Starting ... */
    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);
    MSG msg;
    while(GetMessage(&msg, NULL, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }
    return 0;
}


