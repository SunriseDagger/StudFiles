#include <stdio.h>
#include <cpuid.h>

long myVar = -1;
long myVar2 = -1;
#define c_cpuid(r,leaf) __get_cpuid((leaf),&r[0],&r[1],&r[2],&r[3])
#define __cpuidex(r,leaf,ex) myVar=(ex); __asm("mov ecx, myVar"); c_cpuid((r),(leaf));

int main() {
	__asm("pushfq");
	__asm("popq rax");
	__asm("mov ebx, eax");
	__asm("xor eax, 0x00200000");
	__asm("pushq rax");
	__asm("popfq");
	__asm("pushfq");
	__asm("popq rax");
	__asm("cmp eax, ebx");
	__asm("mov eax, -1");
	__asm("jz RET_ARG");
	// the algorythm is too complicated to be written in asm
	unsigned int regs[4];
	c_cpuid(regs, 0); // maximum input value
	int max_leaf = regs[0];
	if (max_leaf < 2) // no way to find L3 cache info
		return -1;

	c_cpuid(regs, 1); // additional information
	int family = (regs[0] >> 8) & 0xF;
	int model = (regs[0] >> 4) & 0xF;
	
	c_cpuid(regs, 2); // cache and TLB information
	regs[0] &= 0xFFFFFF00; // least significant byte of EAX is invalid
	for (int i = 0; i < 4; i++) {
		if (regs[i] & 0x80000000) { // invalid if most significant bit set
			regs[i] = 0;
		}
	}

	if ((regs[0] | regs[1] | regs[2] | regs[3]) == 0) {
		asm("mov eax, 0x80000006");
		asm("cpuid");
		asm("and edx, 0xFF");
		asm("mov eax, edx");
		asm("jmp RET_ARG");
	}

	// ReSharper disable once CppCStyleCast
	unsigned char *descriptors = (unsigned char*)regs;
	int use_leaf_4 = 0;
	int ret_value;
	const int kb = 1;
	const int mb = 1024 * kb;

#ifdef WIN32
#define RETINFO(s, a, l) ret_value = ((s) << 8) + (l); return ret_value; break;
#else
#define RETINFO(s, a, l) ret_value = ((s) << 8) + (l); asm("jmp RET_ARG"); break;
#endif

	for (int i = 0; i < 32; i++) {
		switch (descriptors[i]) {
		case 0x22: RETINFO(512 * kb, 4, 64);
		case 0x23: RETINFO(1 * mb, 8, 64);
		case 0x25: RETINFO(2 * mb, 8, 64);
		case 0x29: RETINFO(4 * mb, 8, 64);
		case 0x40: RETINFO(0, 0, 0); /* no L3 cache */
		case 0x46: RETINFO(4 * mb, 4, 64);
		case 0x47: RETINFO(8 * mb, 8, 64);
		case 0x49: if (family == 0x0F && model == 0x06) RETINFO(4 * mb, 16, 64);
		case 0x4A: RETINFO(6 * mb, 12, 64);
		case 0x4B: RETINFO(8 * mb, 16, 64);
		case 0x4C: RETINFO(12 * mb, 12, 64);
		case 0x4D: RETINFO(16  * mb, 16, 64);
		case 0xD0: RETINFO(512 * kb, 4, 64);
		case 0xD1: RETINFO(1 * mb, 4, 64);
		case 0xD6: RETINFO(1 * mb, 8, 64);
		case 0xD7: RETINFO(2 * mb, 8, 64);
		case 0xD8: RETINFO(4 * mb, 8, 64);
		case 0xDC: RETINFO(1 * mb + 512 * kb, 12, 64);
		case 0xDD: RETINFO(3 * mb, 12, 64);
		case 0xDE: RETINFO(6 * mb, 12, 64);
		case 0xE2: RETINFO(2 * mb, 16, 64);
		case 0xE3: RETINFO(4 * mb, 16, 64);
		case 0xE4: RETINFO(8 * mb, 16, 64);
		case 0xEA: RETINFO(12 * mb, 24, 64);
		case 0xEB: RETINFO(18 * mb, 24, 64);
		case 0xEC: RETINFO(24 * mb, 24, 64);
		case 0xFF: use_leaf_4 = 1; break;
		}
	}

	if (!use_leaf_4 || max_leaf < 4)
		return -1; // failed, no L3 info found

	int i = 0;
	while (true) {
		__cpuidex(regs, 4, i); /* Deterministic Cache Parameters */
		if ((regs[0] & 0x1F) == 0) {
			RETINFO(0, 0, 0); /* no L3 cache */
		}
		if (((regs[0] >> 5) & 0x7) == 3) {
			int lsize = (regs[1] & 0xFFF) + 1;
			int partitions = ((regs[1] >> 12) & 0x3FF) + 1;
			int ways = ((regs[1] >> 22) & 0x3FF) + 1;
			int sets = regs[2] + 1;
			RETINFO(ways * partitions * lsize * sets, ways, lsize);
		}
		i++;
	}
	
__asm("RET_ARG:");
	printf("%d KB, method: %s\n", ret_value, (myVar2 == 0 ? "AMD" : "Intel"));
	return 0;
}
