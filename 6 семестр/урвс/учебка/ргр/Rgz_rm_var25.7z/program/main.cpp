#include <windows.h>
#include <shlwapi.h> // for wnsprintf
#include "../library/library.h" // include header from nearlying project
#pragma comment(lib, "library.lib") // this is copied after library build
#pragma comment(lib, "shlwapi.lib") // for wnsprintf

#define BUFSIZE 64
int a = -1; // volatile identifier is for thread-safety
volatile int l = -1; // this is not volatile due to passing by reference
volatile library_info li; // volatile identifier is for thread-safety
char buf[BUFSIZE];

DWORD WINAPI ThreadFunc(void* lParam) {
	library_info *ret = (library_info*)lParam;
	GetMetricLevel2(ret);
	return 0;
}

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
	PAINTSTRUCT ps;
	HDC dc;
	// static char array crashed program
	//char *buf = (char*)HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, BUFSIZE);
	switch(uMsg) {
	case WM_PAINT:
		//wsprintf(buf, "Count of FN-keys on current keyboard: %d", a); // wsprintf is unsafe!!
		dc = BeginPaint(hWnd, &ps);
		wnsprintf(buf, BUFSIZE - 1, "Count of FN-keys on current keyboard: %d", li.fn_count);
		TextOut(dc, 30, 20, buf, lstrlen(buf));
		wnsprintf(buf, BUFSIZE - 1, "L3 cache: %d KB, string length: %d", 
			(int)(li.cpuid_info >> 8), (char)(li.cpuid_info % 256));
		TextOut(dc, 30, 40, buf, lstrlen(buf));
		EndPaint(hWnd, &ps);
		break;
	case WM_DESTROY:
		PostQuitMessage(EXIT_SUCCESS);
		break;
	default:
		return DefWindowProc(hWnd, uMsg, wParam, lParam);
	}
	return 0;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrev, LPSTR CmdLine, int nCmdShow) {
	HANDLE hThread;
	DWORD IDThread;
	WNDCLASS wcl;
	HWND hWnd;
	LPSTR szClassName = "SampleClass33";
	wcl.hInstance = hInstance;
	wcl.lpszClassName = szClassName;
	wcl.lpfnWndProc = WndProc;
	wcl.style = CS_VREDRAW | CS_HREDRAW;
	wcl.hIcon = NULL;
	wcl.hCursor = NULL;
	wcl.lpszMenuName = NULL;
	wcl.cbClsExtra = NULL;
	wcl.cbWndExtra = NULL;
	wcl.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);

	if(!RegisterClass(&wcl))
		return GetLastError();
	if(!(hWnd = CreateWindow(
		szClassName, "Resource Management: WinAPI", 
		WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN | WS_CLIPSIBLINGS, 
		0, 0, 350, 120, HWND_DESKTOP, NULL, hInstance, NULL
		))) return GetLastError();
	// DONE: add thread here
	if(!(hThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)ThreadFunc, (LPVOID)&li, NULL, &IDThread)))
		return GetLastError();
	WaitForSingleObject(hThread, INFINITE);
	CloseHandle(hThread);
	// process window object further
	ShowWindow(hWnd, SW_SHOWNORMAL); // or nCmdShow
	UpdateWindow(hWnd); // return 4;

	// standard cycle of processing messages
	MSG msg;
	while(GetMessage(&msg, NULL, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	ExitProcess(msg.wParam); // exit process (not only main thread) with WM_DESTROY code
}